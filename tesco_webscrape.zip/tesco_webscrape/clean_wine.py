import json

# --- Assume 'final_wine_list' is the variable holding the list of dictionaries you just provided ---
# (In a real script, this list would be the result of your scraping loop)

# Example Input Data (using the first 2 items from your output for brevity)
final_wine_list = [
  {
    "producer_brand": "MAD FISH",
    "wine_name": "Mad Fish Sauvignon Blanc Wine 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "306500286",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6bd722f9-a4c4-40c6-8697-cb7ba991f72d/5c9c9438-afb5-459a-8b1a-1c0ed603944a_1100900322.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690471",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Signature Cabernet Sauvignon Red Wine 75Cl",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "306948999",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4243829c-8b84-43a8-b284-ce6e1195fe50/a6ae2c41-da57-4926-84a9-ef39919092e7_213834983.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91969821",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MOST WANTED",
    "wine_name": "Most Wanted Pinot Grigio Wine 75Cl",
    "region": "Italy",
    "price_eur": 13.5,
    "tesco_id": "311949099",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/815c6ae9-68b6-4750-8e0e-98ed7b7e1d05/6232ddac-3899-465a-95ba-0521cc0ba261_1100926132.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687799",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PORTA",
    "wine_name": "Porta 6 Lisboa Red Wine 750 ml",
    "region": "Other",
    "price_eur": 13,
    "tesco_id": "306662491",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6b90de31-b1ee-4bc1-915b-8f974929a76a/21373c3f-06b5-4966-81e8-5df29cd4015e_409387949.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690396",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "A GABB FAMILY WINE",
    "wine_name": "A Gabb Family Wine Sheep Hill Sauvignon Blanc",
    "region": "South Africa",
    "price_eur": 18,
    "tesco_id": "317208754",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/84098ea9-565e-4924-9477-0daf19fb2531/e5162837-737c-49af-868a-d75602318e11_384863964.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687853",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VINEYARDS",
    "wine_name": "Vineyards Fruity Red Wine 75Cl",
    "region": "Spain",
    "price_eur": 6.7,
    "tesco_id": "280117722",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/25cf1c71-03dc-4eeb-975a-abec455c380f/de7836e7-956e-4114-9ce9-e40526c411a5_1137676155.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "19 CRIMES",
    "wine_name": "19 Crimes Red Wine 75Cl",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "299531340",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/839ee7ce-452a-4798-a918-41cf031f6990/83448215-57dc-433a-bbca-6547c3d3601d_294141132.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688509",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA VIEILLE FERME",
    "wine_name": "La Vieille Ferme White Wine 750Ml",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "304402722",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a5749033-44f1-44f6-a60e-159373ad70e9/a45fb110-cf02-4845-b78b-46c32d6fc2d0_2058851716.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690439",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA VIEILLE FERME",
    "wine_name": "La Vieille Ferme Red Wine 750Ml",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "304789436",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cd7c163c-5b08-4e59-a96a-9c91ddd5af4c/191284ef-e7de-455f-b941-31518e52c7fc_903846918.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690469",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "A GABB FAMILY WINE",
    "wine_name": "A Gabb Family Wine The Beekeeper's Shiraz",
    "region": "South Africa",
    "price_eur": 18,
    "tesco_id": "317298421",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e34683a2-1048-4814-a7fb-278317c6dc69/fb472622-11b2-4696-b10a-7cc176b28cf2_439554035.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687843",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Garnacha Wine 750Ml",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "307750287",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7cd9c405-037b-4d40-92e7-665585b9484d/a4994589-cdb3-416c-914b-3797864883fc_77178904.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690458",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CALVET",
    "wine_name": "Calvet Malbec Reserve Red Wine 75Cl",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "306650833",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a5000fd5-6620-4649-b73d-70250a3c3853/8ec3bd98-243b-4a68-9bd5-e316b910d17c_261262289.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690360",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WINE ROUTE",
    "wine_name": "Wine Route Chile Sauvignon Blanc 2.25L",
    "region": "Chile",
    "price_eur": 24,
    "tesco_id": "316550648",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f1f877a5-8f7e-4a2b-b7f2-6f54d79b1019/441fcd96-47fe-419f-923f-cfa452a6e502_581654737.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "A GABB FAMILY WINE",
    "wine_name": "A Gabb Family Wine The Pioneer Cabernet Sauvignon",
    "region": "South Africa",
    "price_eur": 18,
    "tesco_id": "317410237",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/53177fbf-0230-414a-8a80-4986310fb956/9f1beb20-b8ca-48d2-b143-d2a078615c65_1989426513.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687859",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA BURGONDIE",
    "wine_name": "La Burgondie Fleurie French Red Wine 75Cl",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "307149648",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7808d32f-09eb-4ee7-a727-5213bbc96a72/snapshotimagehandler_1741702658.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961751",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€14.00/75cl",
        "offerText": "€14.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "KYLIE MINOGUE",
    "wine_name": "Kylie Minogue Rose Wine 75Cl",
    "region": "Rose",
    "price_eur": 12,
    "tesco_id": "306802015",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fb0234cc-3960-4188-81ee-15365fed930b/2638a8b5-27cc-4653-a6fe-73a6a4b77302_943039502.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687782",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "A GABB FAMILY WINE",
    "wine_name": "A Gabb Family Wine Wild Child Chardonnay",
    "region": "South Africa",
    "price_eur": 18,
    "tesco_id": "317305201",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/75b40d44-c65e-42a9-a1dd-9d5b8754d1ce/235ad342-0874-4e2e-9e5f-431c9c9b5b47_1816009864.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687846",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Jammy Red Wine 750Ml",
    "region": "Other",
    "price_eur": 10.5,
    "tesco_id": "305983711",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/90ff6c52-ae3b-4d2f-98d2-cf5c4186e19f/9363263f-b597-4694-8088-14591d2598bf_1017987656.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688115",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Signature Sauvignon Blanc 750Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 17,
    "tesco_id": "265814236",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/273cbb80-176b-4995-baf8-0d7b9b13a4f2/6a35689d-4ed8-4186-8c48-f717a6842305_1174078210.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91969826",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WINE ROUTE",
    "wine_name": "Wine Route Chile Merlot 2.25L",
    "region": "Chile",
    "price_eur": 24,
    "tesco_id": "316934206",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c8f84f9a-4b68-4a48-ad8b-ace992f99b0e/34a33c60-6cc8-4359-8fe3-befa2f354f9f_290118899.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Zero Alcohol Free Rose Wine 750Ml",
    "region": "No & Low Alcohol Rose",
    "price_eur": 5.5,
    "tesco_id": "306937875",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c7950041-a750-488b-8761-910b35c6df2d/7f648959-5260-4f07-955e-2770c43a53c7_1836860156.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690395",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€5.00/75cl",
        "offerText": "€5.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 5.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MAD FISH",
    "wine_name": "Mad Fish Shiraz Wine 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "306502825",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a70cb35f-18d4-42fd-b0b6-bd3c9bf3ba88/6a8224d6-e1c1-4959-9a0d-8b1df7e697d7_1225985478.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690436",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PICCINI",
    "wine_name": "Piccini Memoro Red 75Cl",
    "region": "Italy",
    "price_eur": 20,
    "tesco_id": "268451032",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/54beeb5f-07d8-427a-8345-215185bb6cfd/537f1688-7ede-47f4-aae5-a686d24a8a2f_1091901556.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690354",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BRANCOTT ESTATE",
    "wine_name": "Brancott Estate Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 14,
    "tesco_id": "255244712",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4a9bc6c9-0f36-44b4-b7ee-3cc4c22a18c4/79117c61-cf8d-4144-a3e6-2c2cdc3f6c4c_1580392185.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688339",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MUCHO MAS",
    "wine_name": "Mucho Mas Vino Tinto Wine 75Cl",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "309493858",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4ec06332-e519-4c87-a6fc-3e9546313ae3/723a44cc-5352-43b9-ba56-d299f5d42659_1012730430.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690384",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAMILLIE PERRIN",
    "wine_name": "La Vieille Ferme Rose Wine 750Ml",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "305986754",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7083c43e-d7f6-4554-b7a7-956f56e90111/d5372266-3550-463a-820a-c689e0503a9b_1268517372.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690470",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LES DOMAINES",
    "wine_name": "Domaine Arnaud Sauvignon Blanc 750Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 17,
    "tesco_id": "276067803",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/966f53d6-b8f0-40b0-afaf-13b54d9a8fdc/snapshotimagehandler_1757317953.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690435",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "254192146",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/33a09842-8711-42b2-86c4-afb76e7cad30/739fa079-12b9-451b-a1e8-f5edb0a377b6_1698347160.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914328",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OCEANS EDGE",
    "wine_name": "Oceans Edge Pinot Grigio 75Cl",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "265043301",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/28c0dd9e-6f96-431d-b508-a5f7dd3dc9b1/snapshotimagehandler_957685979.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690413",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VINEYARDS",
    "wine_name": "Vineyards Zesty White Wine 75Cl",
    "region": "Spain",
    "price_eur": 6.7,
    "tesco_id": "280134776",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/05601c11-b4f6-40cc-9be2-f4c2c84a30b3/ee26ab9c-7303-4be0-b8a8-21c970d2c7fa_271403183.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "PORTA",
    "wine_name": "Porta 6 White Wine 750Ml",
    "region": "Other",
    "price_eur": 13,
    "tesco_id": "309480165",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/48a3c090-0c7c-46e3-a7b1-774954ed9964/f7ee4f3f-693d-4387-8d77-8f27df2afea9_277382414.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690453",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SMILING DONKEY",
    "wine_name": "Smiling Donkey Red Wine 750Ml",
    "region": "Portugal",
    "price_eur": 15,
    "tesco_id": "313007474",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/47cfc6a8-c983-48a7-be95-ab92ec5efaf8/b23a1977-aa72-46e4-966e-f968d18f0d42_1692391471.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687802",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "The Sardine Submarine",
    "wine_name": "The Sardine Submarine Tinto Red Wine 75Cl",
    "region": "Portugal",
    "price_eur": 12,
    "tesco_id": "313160711",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/46059a5d-8391-4a46-a91f-ea530cc721c4/7b147048-23d2-4b9e-9c75-2a352bba58a3_1773292785.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687800",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GUIGAL",
    "wine_name": "Guigal Cotes Du Rhone Red Wine 750Ml",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "304376844",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a47fb837-77e8-4614-a743-22b3221cb459/6fa16a53-fec5-4149-aff1-db2a9b36630e_604055577.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LA BRUNAUDE",
    "wine_name": "La Brunaude Cabernet Sauvignon 750Ml",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "267051518",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4f6c0822-42e2-4c1a-a8d7-1ff02ba4b122/snapshotimagehandler_589942956.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690442",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASA ROSCOLI",
    "wine_name": "Casa Roscoli Garganega Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 7,
    "tesco_id": "272199532",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/857f3397-8f1c-4937-bd4d-94753ef887a0/891cfcdf-234b-4f69-8b42-25387ccd1df3_1441400557.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "254829633",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b8902b02-04a0-475e-9b04-74b8d392e238/54b2cc12-102e-4d54-9753-5ff30f99550a_23542351.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688077",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "256999289",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/27547443-6b4e-4564-ac2f-ae31ddeaa0c7/b7630b10-4297-4ce1-adbb-39b81eae9d32_1015207776.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914330",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO DEL DIABLO",
    "wine_name": "Casillero Del Diablo Pinot Grigio 75Cl",
    "region": "Pinot Grigio",
    "price_eur": 10,
    "tesco_id": "268745376",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/86affda9-c6b8-4b8b-8752-512a091d2bc4/6d3fb8a5-eed1-403e-9598-76017e312250_131059379.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914331",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Ca de Lago",
    "wine_name": "Ca De Lago Cabernet Sauvignon",
    "region": "Italy",
    "price_eur": 7,
    "tesco_id": "271165741",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0482477e-d3cc-48ca-9976-504d7ab58d7c/snapshotimagehandler_785203890.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MUD HOUSE",
    "wine_name": "Mud House Chilean Sauvignon Blanc Wine",
    "region": "Chile",
    "price_eur": 13,
    "tesco_id": "310119283",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/85a8052a-1208-432a-ba08-402132e15a6e/7e2a7e53-283a-4a6e-a8e0-7f1e8679d538_1509802054.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690401",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Sauvignon Blanc 187.5Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "274699225",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/952908d2-07ee-4d6c-9e62-ecd8f814b3b1/snapshotimagehandler_1707735673.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Signatu Re Merlot 750Ml",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "266731522",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1925a004-f8f0-438f-87ab-edd405c0848c/2baff4df-962a-433f-9f8e-35632417903d_1484156154.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91969820",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ISLA NEGRA",
    "wine_name": "Isla Negra Sauvignon Blanc Px 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 16,
    "tesco_id": "261735917",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/26de328c-50d0-47c6-8942-142826ff1e9d/edcaa3e0-d458-4241-9be0-bd1085485a1c_1792846421.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690450",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "254844107",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c8e67124-f0c8-4240-9523-fc4431d4045f/decf04d9-bd7d-4d69-b861-d06aa2f273e4_1346291730.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690361",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OYSTER BAY",
    "wine_name": "Oyster Bay Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 13.5,
    "tesco_id": "260222846",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/302fb867-b30f-4805-9bbc-e19835613fdd/1d287668-d1fb-4591-b590-a66d80dfc09b_816849164.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91924455",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Bicicleta Chardonnay 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "253412505",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/62ead15a-5da1-4dd3-ae86-e5b7afcf036c/e31a2bf1-0c4a-45a5-816e-145d246c01d0_826740402.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688157",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Chardonnay 187.5Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "274698975",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3f0a033d-23c0-4f3f-b5c1-79735c852f56/snapshotimagehandler_1380799543.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BODEGES",
    "wine_name": "Faustino V Reserva Rioja 75Cl",
    "region": "Spain",
    "price_eur": 18,
    "tesco_id": "258014197",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ea9c7761-7963-4d5a-bc04-e8b79e6488b7/1cc2343d-45a7-4488-8404-e62426cec016_1443480463.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688388",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ISLA NEGRA",
    "wine_name": "Isla Negra Malbec 75cl ",
    "region": "Chile",
    "price_eur": 16,
    "tesco_id": "316805164",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f4937d31-6c6c-43ca-8a57-0ab04e81e284/baff24e3-1463-4b5d-ac19-b84f44ff841c_1914097771.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690440",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Moscato 75Cl",
    "region": "Rose",
    "price_eur": 10.5,
    "tesco_id": "268450309",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a456dcd8-32bf-4e0e-b474-723859e78776/264ee1a7-8c15-4cc9-b97b-d51575635c56_161015626.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688110",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GRAHAM NORTONS",
    "wine_name": "Graham Norton Western Cape Sauvignon Blanc 75Cl",
    "region": "South Africa",
    "price_eur": 13,
    "tesco_id": "310656723",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0af75651-9757-4b75-97b4-74321565e0cf/f081afa2-6ed8-4609-922c-9712ab570e32_1089759849.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688035",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MIRLA BAY",
    "wine_name": "Mirla Bay Sauvignon Blanc 750 Ml",
    "region": "Chile",
    "price_eur": 19,
    "tesco_id": "281024087",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b01ef2cf-2fa4-4afe-a115-5ea53b8c7d23/snapshotimagehandler_723822335.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688093",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TORRES",
    "wine_name": "Torres Sangre De Toro 75Cl",
    "region": "Spain",
    "price_eur": 10,
    "tesco_id": "257204446",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b33b2597-10c5-4da2-b38d-559c4ea24063/f52e5ac1-49bc-4d7a-afc0-405ffbae94a4_1766136560.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91908849",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PICCINI",
    "wine_name": "Piccini Memŏro White",
    "region": "Italy",
    "price_eur": 20,
    "tesco_id": "275156636",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bb559ccd-147b-4a00-a304-d652d8add2b7/bd48e997-b876-401d-a711-48913fb7dd6d_676225636.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690461",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LES DOMAINES",
    "wine_name": "Domaine Arnaud Syrah 750Ml",
    "region": "France",
    "price_eur": 17,
    "tesco_id": "276067688",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/224f93b8-c02a-4aab-9bb5-bcffdacf9626/snapshotimagehandler_1585952844.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690428",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LOS CARDOS",
    "wine_name": "Los Cardos Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 10,
    "tesco_id": "266550315",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9e14cb8b-c9f9-4e2d-a4d8-9158e29f7520/8edeeb6e-927e-4c39-aad2-456e0b21167a_2066298142.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688079",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Chardonnay 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "254936765",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/766fa3f9-a2e5-4332-b291-ee639db22683/d7eb37d8-e871-4ca3-8ec7-6bd9a8e14ebb_1615929731.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688082",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Malbec 750Ml",
    "region": "Australia",
    "price_eur": 10.5,
    "tesco_id": "295639634",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f3c02f7f-5b92-47e0-b417-d0e665c47a2a/190d688d-37a9-4e9e-bac3-70dcbb7e92cf_673245498.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690466",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "MALAMIGO EL REBELDE RED BLEND WINE 750ML",
    "region": "Spain",
    "price_eur": 13,
    "tesco_id": "317208351",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/27460771-3076-40ec-aa77-199cf5db40ec/5c4f2a92-68f7-48c5-9491-7a6fbc5ddb0e_969372016.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688406",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DOMAINE ARNAUD",
    "wine_name": "Domaine Arnaud Cabernet Merlot 75Cl",
    "region": "France",
    "price_eur": 17,
    "tesco_id": "255217492",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/41abac56-ef8d-4f94-8d75-7a46792402d3/snapshotimagehandler_3880979.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690465",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BLACK LABEL",
    "wine_name": "Mcguigan Black Label Pinot Grigio",
    "region": "Pinot Grigio",
    "price_eur": 10.5,
    "tesco_id": "259328193",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c774dd9d-abe8-44e0-8cc2-07713de451e7/a5002bd8-5b21-4193-9902-d3000edf04bd_665213923.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690346",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SQUEALING PIG",
    "wine_name": "Squealing Pig Sauvignon Blanc 750ml",
    "region": "New Zealand",
    "price_eur": 15,
    "tesco_id": "314596430",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7a1ca47d-fc03-4739-b686-b8f28617ae1e/123f9ae2-402c-4b93-9575-709febad737b_1650812041.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688018",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Reserva Especial Shiraz 750Ml",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "314590511",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/23abf848-52d2-4536-bf82-53b00f316480/b2638b3d-a018-4e2c-8bb2-91c53b972d11_1345981599.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688088",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUES DE RISCA",
    "wine_name": "Marquis D'alban Reserva Bordeaux Superior 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "255710374",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/aa1c19f2-88eb-4bc1-bb1a-433a3118cfa6/3844e454-1bc2-4308-94df-5c79e043f5fe_1339159239.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687741",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PINOT PINOT",
    "wine_name": "Pinot Pinot Pinot Grigio Sparkling 200Ml",
    "region": "Small Bottles",
    "price_eur": 2.99,
    "tesco_id": "297102609",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7bed2718-753f-4645-8be9-4c953bdfb8f7/8d1f49b2-d2ad-4f86-acc8-ff7a752bb1c2_27637160.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687772",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.74/75cl",
        "offerText": "€2.60 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 2.99
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BRIGHTWATER BAY",
    "wine_name": "Brightwater Bay South African Sauvignon Blanc",
    "region": "South Africa",
    "price_eur": 12,
    "tesco_id": "317529915",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3132a902-db9b-43d6-abc1-5dbcfddf44e0/c824bbac-65bb-4579-bee5-6b6906eba3ac_806134696.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690408",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Marlborough Pinot Noir 75Cl",
    "region": "Pinot Noir",
    "price_eur": 15,
    "tesco_id": "280144462",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/093dcd9f-a0b0-42a0-827a-9d3542fbcd00/75dfb260-f919-43d0-9d9c-5fc590771823_1242852579.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687760",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAMPO VIEJO",
    "wine_name": "Campo Viejo Rioja Reserva 75Cl",
    "region": "Spain",
    "price_eur": 16,
    "tesco_id": "257863212",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b9e0237f-d92e-437d-9eff-f5cf4a37125f/0196f8bf-a3f6-4741-b150-67a6ee3feacd_2121284009.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688492",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LACHETEAU",
    "wine_name": "La Brune Pinot Noir 75Cl",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "278936434",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/549128fa-541e-4086-a6e7-99bac572e826/61f1d9da-1880-4464-b303-efc2039a0e0c_866349815.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690468",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Bicicleta Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "255547515",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bda9e943-5893-4360-8892-3a15bc6bc3c4/7d3e48e7-ba44-413b-a4e8-99a6d5acaec5_853577150.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688158",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FREIXENET",
    "wine_name": "Freixenet Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 15,
    "tesco_id": "306665257",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/081f3f89-4ac1-4da5-8f59-ce429d123153/7e759747-0069-475c-89cd-d8e54013b78b_1395485343.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688146",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CARMEN",
    "wine_name": "Carmen Merlot 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "250803480",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d66dbb9e-3de0-4342-8377-816ce4b80aaa/snapshotimagehandler_2137899914.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688098",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "greasy fingers",
    "wine_name": "Greasy Fingers Luscious Red 75Cl",
    "region": "Australia",
    "price_eur": 14,
    "tesco_id": "316634627",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4782c954-f72c-44be-8b52-11694690a9be/0fe02130-6a79-490d-a7ed-7409b5e4bdd8_1809444810.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688310",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Zinfandel",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "315589869",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/47a3e791-5e2f-4c18-bc78-b80d25adf74e/8fedb75a-8289-46d2-9f2b-8c1828bc1de6_2081684221.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688597",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-05T23:00:00Z",
        "unitSellingInfo": "€13.00/75cl",
        "offerText": "€13.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcg Signature Pinot Grigio 75Cl",
    "region": "Pinot Grigio",
    "price_eur": 17,
    "tesco_id": "268775697",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f6ddfa00-f3d2-4a42-ac46-1c595aa83a16/4ccf86db-03da-4d7b-9793-c289ace5a835_234760534.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91969817",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CELLIER PRINCES",
    "wine_name": "Cellier Des Princes Grande Reserve Cotes Du Rhone 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "306808994",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f3016c42-003d-41cd-ace1-72aa1ac4997f/467fe932-22a5-4dad-8302-cf7b0cb4d533_2064723143.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690400",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Signature Shiraz 75Cl",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "258746062",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/83fae1b9-5786-436a-ad53-a7c9ef9c4a51/c16046fe-9796-4716-9280-bc43b6bce889_115040007.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91969813",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAMPO VIEJO",
    "wine_name": "Campo Viejo Rioja Tempranillo 75Cl",
    "region": "Other",
    "price_eur": 12,
    "tesco_id": "250218971",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4e2b706f-8043-4ec9-867e-76a16b198f4a/21fbf3b1-d892-49dc-97c2-bcea4caa2282_1237088001.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688341",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Prosecco Doc 75Cl",
    "region": "Prosecco Sparkling",
    "price_eur": 18,
    "tesco_id": "262309747",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/57432dcd-47b1-4961-b24b-55e2a8a59955/92c96db2-e9af-4f08-b618-99c937aab97d_1340481321.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688506",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€15.00/75cl",
        "offerText": "€15.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PICCINI",
    "wine_name": "Piccini Memoro Quattro Elementi Merlot Veneto",
    "region": "Italy",
    "price_eur": 20,
    "tesco_id": "317185422",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/02812ef9-5b28-45ca-9604-984202969b3f/553ca20f-cca3-4284-85e4-9b23297ad3a3_567410264.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690385",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CHATEAU",
    "wine_name": "Chateau Mezain Rouge 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "253881801",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/05d343ad-4665-4798-b1c6-04c9be3c6966/23cfcf00-01cc-401c-a98e-a6b915e7f7b6_1130698021.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690484",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Pinot Grigio 75Cl",
    "region": "Pinot Grigio",
    "price_eur": 10.5,
    "tesco_id": "266183202",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f0fd29b6-4527-495d-b2c5-797d328ee84a/f7671f4c-4be3-4795-a72b-9441383277d6_1998121409.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688109",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "[ yellow tail ]",
    "wine_name": "Yellow Tail Pinot Grigio 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "262271087",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9e2766c9-6315-40ca-ab6f-74025f543b65/43488386-2066-4d46-9d73-4eb885a7ff7f_1158833291.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959368",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Shiraz 75Cl",
    "region": "Australia",
    "price_eur": 10.5,
    "tesco_id": "253237874",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dbd52662-b144-4296-bc58-b325389f1aca/eda502fe-349d-4164-8fc4-8e1fca8d66ee_755448434.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690479",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Rioja Reserva 75Cl",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "261787141",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/30b3bc2c-bce3-4f5d-ba34-c575ee4fcc96/c7328874-2caa-4cf4-97eb-e6bde46da590_592999911.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690448",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BEND IN THE RIVER",
    "wine_name": "The Bend In The River Sauvignon Blanc 75Cl",
    "region": "Chile",
    "price_eur": 8,
    "tesco_id": "267547278",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fc1483d4-64c4-44e6-be47-bd2e0bbbcb75/0d6c2fb5-f091-4018-83e5-9bdd4c17a851_2060415535.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "HARDYS",
    "wine_name": "Hardys Stamp Chardonnay Semillon 187Ml",
    "region": "Small Bottles",
    "price_eur": 2.6,
    "tesco_id": "272783036",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/17f4f78e-076c-442c-b6f3-b293314cc102/ee49027a-6b27-4a55-816c-e45c3f685d55_59757276.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Sauvignon Blanc 18.7Cl",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "268739712",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2d3483e7-a446-46c8-b9f0-b62c1ebb53d0/94f522b2-d5b2-4e89-8dee-cea2a81a4d71.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "ISLA NEGRA",
    "wine_name": "Isla Negra Chardonnay/Px 75Cl",
    "region": "Chile",
    "price_eur": 16,
    "tesco_id": "253805882",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/81a7b1ee-d5fa-4492-9148-61fcf5eccdec/134e58cc-eac5-4879-9fb5-5da7530effc9_1682930161.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690474",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Cabernet Sauvignon 75Cl",
    "region": "Other",
    "price_eur": 10.5,
    "tesco_id": "277053144",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/be9cb0fb-1a11-41f0-bb14-171947824c24/64b4f4ed-f990-44a1-b782-788ab25b9d23_2078840312.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688108",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Mirla Bay",
    "wine_name": "Mirla Bay Chardonnay 75Cl",
    "region": "Chile",
    "price_eur": 19,
    "tesco_id": "304836266",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d0dcf19a-f979-41be-98fb-aaf2e3427988/0f916dbc-beb3-4cac-80b2-5ca4376f872b_1653190650.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688096",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "The African Horizon",
    "wine_name": "The African Horizon Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "313956801",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs-mktg/b0b04216-fa73-466d-a9d7-c9fcfa1ce9b3/no-image.jpeg",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92245166",
        "promotionType": None,
        "startDate": "2025-04-08T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Reserva Especial Sauvignon Blanc 75Cl",
    "region": "France",
    "price_eur": 14,
    "tesco_id": "310679581",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/22594a27-7c2b-442f-b9ed-431967f22bb7/ecda9a44-81d4-4c06-a09a-399fd51c2919_2082720257.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688351",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Merlot 75Cl",
    "region": "Merlot",
    "price_eur": 10.5,
    "tesco_id": "253238130",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d864fd9d-a5b3-4fdc-8ee1-d129aabf5f0c/740d6942-45fd-4d6c-9164-21ba056ebf42_1837959092.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690394",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LAS MORAS",
    "wine_name": "Las Moras Dada No8 Chocolate 75Cl",
    "region": "Argentina",
    "price_eur": 10.5,
    "tesco_id": "303917799",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c8eef69a-36d8-49aa-b5f3-1b78c6c3c920/9cf3a3c1-2f5b-4df6-be29-2f014ddd6732_1239603726.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961762",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "HARDYS",
    "wine_name": "Hardys Crest Chardonnay White Wine",
    "region": "Chardonnay",
    "price_eur": 17,
    "tesco_id": "254819789",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5fd6c080-4cab-47c0-b255-7cc9cb10952a/8a089319-e740-4d81-86ed-c325c74ebded_959260493.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688334",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Merlot 75Cl",
    "region": "Merlot",
    "price_eur": 10,
    "tesco_id": "251295916",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c3a61917-c799-4330-8fbd-6ef139cc1b22/0768f55e-bf61-472b-87b7-749b3a3fd105_1752865386.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914327",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ISLA NEGRA",
    "wine_name": "Isla Negra Merlot 75Cl",
    "region": "Chile",
    "price_eur": 16,
    "tesco_id": "252954913",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5cc8f3aa-d91f-473e-906a-b47d94b36fac/60147a40-f01f-452c-a13e-4257c70108af_1852721582.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690387",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Montepulciano D'abruzzo 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "266680005",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6391a1df-a5e9-4081-a71e-033f3a9a6206/874ca7e8-cf73-47b0-82b5-2f6ce19ba04c_993038318.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "OCEANS EDGE",
    "wine_name": "Ocean's Edge Sauvignon Blanc Blanc 75Cl",
    "region": "California",
    "price_eur": 17,
    "tesco_id": "286020164",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/20281fef-55a5-4ae0-aad3-eae09636aa0b/snapshotimagehandler_624784549.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690352",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Chardonnay 75Cl",
    "region": "Chardonnay",
    "price_eur": 10.5,
    "tesco_id": "253238308",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8a837824-3af6-4fd7-bfac-2fa7b8a051ca/6437bab6-c3ec-449a-a20a-40882cf47ecf_861312927.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690459",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "HARDYS",
    "wine_name": "Hardys Stamp Shiraz Cabernet 187Ml",
    "region": "Small Bottles",
    "price_eur": 2.6,
    "tesco_id": "272783111",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d0aeddd9-c1be-4850-8be2-948d1422d058/347465a7-325f-473e-83f4-3b0a6a47dfa7_1721323065.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CHAIS DE BOURLEMONT",
    "wine_name": "Chais De Bourlmt Cotes De Duras White 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "284659114",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c5bfc8bc-43bd-412a-8dee-d559672b5177/snapshotimagehandler_900539505.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690443",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Malbec 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "294015775",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3040387d-7f8d-4b88-be39-99137e991588/3b903443-2628-4588-ad9f-db4ad393d012_1872177843.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688091",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Rose 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "266434386",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2f3d72ce-ce33-42f7-9861-05db2f6840bf/9b36cd78-93c9-4f5e-9dfd-49994a7f9490_1980791378.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914326",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PICCINI",
    "wine_name": "Piccini's Collezoine Oro Chianti Riserva",
    "region": "Other",
    "price_eur": 12,
    "tesco_id": "262262036",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c480e067-d515-4ca4-adfc-58e08e80ee73/74202824-c3cd-44de-a586-4f19700997da_1149635385.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690432",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Château Mezain",
    "wine_name": "Chteau Mezain Bordeaux Blanc Aoc 750 Ml",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "298764895",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ed1a6e79-0bef-4822-8d82-267818221a76/66b512ab-bd00-4395-bb1f-7ce31852d6b7_554705616.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690463",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Pinot Pinot",
    "wine_name": "Pinot Grigio Pink Fizz 200Ml",
    "region": "Small Bottles",
    "price_eur": 2.99,
    "tesco_id": "304124901",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ed12db36-9d6b-459f-9743-3a12ec03ee61/d0e93c69-1eb9-4a4d-bb58-3e817d1e2d01_340304594.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687776",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.74/75cl",
        "offerText": "€2.60 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 2.99
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MIRLA BAY",
    "wine_name": "Mirla Bay Pinot Noir 750 Ml",
    "region": "Chile",
    "price_eur": 19,
    "tesco_id": "281024162",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/075abb84-cede-47e7-9ce6-6b91cb0cc400/snapshotimagehandler_908833707.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688094",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Organic Rueda Verdejo",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "316643389",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f5a12dbc-b6a5-448a-b9a6-4bed5f315e93/d4e71d47-c3a2-4e51-ba4e-bcdcdf465463_1701186.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687849",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VINA ALBALI",
    "wine_name": "Vina Albali Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 10,
    "tesco_id": "299970551",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/04775e4a-1b61-46c4-85a5-b10ed9f2e2cb/0ffcae93-ac6c-45de-86cb-a3111cd2c65f_1236787844.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690415",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LATERAL",
    "wine_name": "Lateral Chilean Sauvignon Blanc 75Cl",
    "region": "Chile",
    "price_eur": 7.5,
    "tesco_id": "309762448",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e076ff7b-2dba-47c7-a8bd-fdbec4392220/f69189a7-7b12-40ca-a521-4c52abfca326_2012397876.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Bicicleta Pinot Grigio 750Ml",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "314309417",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f3ec7715-819d-4984-bc9b-feb928885edd/aad3f212-b6c4-481f-af6e-6c5f617067f7_1256163013.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688159",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "[ yellow tail ]",
    "wine_name": "Yellow Tail Sauvignon Blanc 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "272640281",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3c0f3952-d187-41fa-8f03-ed15f58189e1/5d18eaf9-8f8d-4c9a-b3c0-d3c4181ac8d8_1602459644.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959427",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FINCA LAS MORAS",
    "wine_name": "Las Moras Dada 391 Sauvignon Blanc 750Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 10.5,
    "tesco_id": "315360926",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/afd3f539-9453-49ea-987e-494f27251554/5fb9d245-d28f-4a9b-ab54-d1edc1d8388c_93198038.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961761",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Black Tower",
    "wine_name": "B Fruitiful Rose Strawberry Plus Raspberry 75Cl",
    "region": "Rose",
    "price_eur": 5,
    "tesco_id": "304696494",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fb5bd7bd-3242-4caf-8c67-3e7e014368a3/41d63e76-27e8-4834-969c-9bff2e3228f0_1853077618.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CASA MANA",
    "wine_name": "Casa Mana Chardonnay 75Cl 75Cl",
    "region": "Spain",
    "price_eur": 7.4,
    "tesco_id": "310133023",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/eca7e008-0338-45be-8a5f-128ea5730a80/8ad918f1-6eb1-4259-bc5e-899e1b1a195c_1083947392.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MOST WANTED",
    "wine_name": "Most Wanted Malbec 187Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "314432164",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9e46fdde-39be-44ed-9bf8-4bdee0d25afe/3c24ecef-abc2-4d4a-bece-4ce72519731e_13082885.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "ATMOSPHERE",
    "wine_name": "Atmosphere Muscadet 750Ml",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "309750825",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c6f08316-5062-48c6-820d-6ebca2e95099/af72e776-932d-48c5-91e2-8c7ac4f0931f_807706609.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687790",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "THE BEND IN THE RIVER",
    "wine_name": "The Bend In The River Pink 75Cl",
    "region": "Other",
    "price_eur": 8,
    "tesco_id": "255961871",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c90b784b-965f-4a3a-96ee-1f2dfb31c567/84f198f3-9f45-47fa-9bd5-45536fb96423_306546736.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CLOUDY BAY",
    "wine_name": "Cloudy Bay Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 38,
    "tesco_id": "303485503",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9ac34414-bb3f-4737-9308-07ade9136b28/9bb9e121-2fd1-4dc4-87bc-1498754b8e38_434150060.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LIONSGATE",
    "wine_name": "Lions Gate Sauvignon-Blanc 75Cl",
    "region": "South Africa",
    "price_eur": 15,
    "tesco_id": "303972059",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/953b3d7b-1dd4-40dd-b865-de052787803a/a0f04a54-2303-47bc-9e27-c3caafcc6059_2068923290.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690422",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€7.50/75cl",
        "offerText": "€7.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FRENCH CONNECTION",
    "wine_name": "French Connection Cotes Du Roussil Village 750Ml",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "266879226",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4d59263e-5213-497f-bde6-03384024cb15/8e344716-7166-4076-9d98-b6d837a87040_281458378.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91924886",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "HARDYS",
    "wine_name": "Hardys Crest Sauvignon Blanc White Wine",
    "region": "Sauvignon Blanc",
    "price_eur": 17,
    "tesco_id": "293657356",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/137e58b9-cf1f-491b-bc6d-ea0b2c3fba9e/96aaab46-2678-42f1-9d59-dbdb20e3bf1d_2006874662.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688333",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Marlborough Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 12,
    "tesco_id": "251108915",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/36c682dc-b442-400a-bb19-78df3d3a58ff/63700655-eda0-49cc-abe0-c6377e23d108_612524560.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690380",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DOMAINE ARNAUD",
    "wine_name": "Domaine Arnaud Finesse Rose 75Cl",
    "region": "France",
    "price_eur": 17,
    "tesco_id": "260221703",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a0b0e6e6-4944-4f26-8492-bc58216e29f2/snapshotimagehandler_499081163.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690368",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DOMAINE ARNAUD",
    "wine_name": "Domaine Arnaud Chardonnay 75Cl",
    "region": "France",
    "price_eur": 17,
    "tesco_id": "255217682",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/851a0503-3512-48fe-980d-d00ad89fc1c9/snapshotimagehandler_1198023782.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690486",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Pinot Grigio 75Cl",
    "region": "Pinot Grigio",
    "price_eur": 10,
    "tesco_id": "296747176",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e3f5d3f9-14cd-45b8-968c-68a070cd6873/fa3750c2-d8ca-406e-9f85-eb9b0bfde172_1522085400.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688089",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CELLIER PRINCES",
    "wine_name": "Cellier Des Princes Cotes Du Rhone White 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "306951926",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/81bdbc31-37aa-4e5b-ad7e-7f0d776487cf/5756c6f2-4ec7-4c99-a655-8a9dad78ec31_1693425469.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690353",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "APOTHIC",
    "wine_name": "Apothic Red 75Cl",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "278453199",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6635e091-7d61-4cb2-84ef-4f89c43eddfc/514d8bc5-7604-41ea-beeb-bace2f0b7960_1352369160.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688049",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Signature Chardonnay 75Cl",
    "region": "Chardonnay",
    "price_eur": 17,
    "tesco_id": "258711118",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9fa67fee-3433-447a-a97e-7059131a6422/d4d509e3-6d6b-4e0a-bcf0-15464adeaefc_382795638.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91969811",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Shiraz 187Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "285313833",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/30cf32e1-1bd7-405c-93aa-c2c6142f1548/43531d52-c1cf-43c7-b9ff-a332a0aca3a6_652581252.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BNED IN THE RIVER",
    "wine_name": "The Bend In The River Pinot Grigio 75Cl",
    "region": "Other",
    "price_eur": 8,
    "tesco_id": "261928806",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dcf19bc2-2c27-42fa-a240-4c192392dc0b/89fdbef1-710f-41b2-8ab7-01526e5e9fe4_350994245.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GRAHAM NORTONS",
    "wine_name": "Graham Nortons Own Shiraz 75Cl",
    "region": "Australia",
    "price_eur": 13,
    "tesco_id": "297501720",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6e4d4564-4d8c-4eef-81c2-3850f9a53bfc/9231e95c-eb13-4873-aa6f-e766b06cf97e_900185523.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690476",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Italiano Lambrusco Rosso 75Cl",
    "region": "Italy",
    "price_eur": 4.5,
    "tesco_id": "312566777",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1d016485-c92a-43c5-8757-5548bc2a7e7e/3b56f897-df8f-4ba9-8452-8f1a39cd8f66_274911250.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CAMPO VIEJO",
    "wine_name": "Campo Viejo Rioja Garnacha 75Cl",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "280145262",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/707fc170-71c3-4837-9802-4f0199e5d664/86a460c0-57a4-41e6-a0db-6964086ea2ad_211332111.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688342",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TURNER ROAD",
    "wine_name": "Turner Road Reserve Merlot Red Wine",
    "region": "California",
    "price_eur": 17,
    "tesco_id": "260572903",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/459aaa03-dbe1-4637-b9dc-d30c41360823/74bfafb1-ba60-4aaa-af1c-2563b85c9925_1646595493.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687744",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAPARELLI",
    "wine_name": "Caparelli Soave 75Cl 75Cl",
    "region": "Italy",
    "price_eur": 7.5,
    "tesco_id": "311447065",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d9bde059-1243-4047-b7d0-0683218a411d/a4e1404c-0d6c-42b8-92de-9ae4340f4d9b_1196600497.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot White Zinfandel 187Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "304104833",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/700831be-9a51-4e02-964d-b9467c86588e/e73f67bb-c292-4108-9861-e631805720cf.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "RAGNATELA",
    "wine_name": "Ragnatela Appassimento Puglia 75Cl",
    "region": "Italy",
    "price_eur": 13,
    "tesco_id": "314577902",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d6043064-e006-420b-aade-fd4df490ac2f/ae9144d9-0b97-425a-b09f-5f693e26ee25_1686294319.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687824",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Black Tower",
    "wine_name": "B Fruitiful White Passion Fruit Plus Pineapple 75Cl",
    "region": "Rose",
    "price_eur": 5,
    "tesco_id": "304696459",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/82f4638b-da86-4a3c-acc7-0c821ab34c0a/7cd10134-4c9e-465b-8f16-e8a43780e5e6_968233250.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "Mirla Bay",
    "wine_name": "Mirla Bay Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 19,
    "tesco_id": "304816958",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6539ed1c-b0da-4a7f-9d3e-e12be599d867/e5ea5ef3-8bd1-498a-be6f-c85d8d7818a7_1569133975.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688095",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "STORMHOEK",
    "wine_name": "Stormhoek Pinot Grigio 75Cl",
    "region": "South Africa",
    "price_eur": 10,
    "tesco_id": "304000247",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/647af1bd-7168-474f-87fc-35c8df617783/snapshotimagehandler_1313982257.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690417",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 De Alcoholised Sauvignon Blanc 750Ml",
    "region": "Wine",
    "price_eur": 5,
    "tesco_id": "310162495",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d33e374b-557d-4672-a9cb-f3370c6f6ec9/4f01343e-1d99-4b5d-8027-e59de5a680db_848735196.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LOS CARDOS",
    "wine_name": "Los Cardos Cabernet 75Cl",
    "region": "Argentina",
    "price_eur": 10,
    "tesco_id": "266550200",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7bdc2483-95d1-414a-80cb-27a66110a1a0/6d3ecca3-8609-47fc-9f33-bd68edc364f0_1708095685.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688090",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LOUIS JADOT",
    "wine_name": "Louis Jadot Pouilly Fuisse 75Cl",
    "region": "France",
    "price_eur": 40,
    "tesco_id": "250081347",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/06380270-a674-4d66-bc09-6a0f836ef083/c89c496b-8112-44ee-b216-81e2d1074af5_218438420.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "THE PALE",
    "wine_name": "The Pale Rose 750ml",
    "region": "France",
    "price_eur": 16,
    "tesco_id": "312110370",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c3257f2a-2bda-4cc0-90ba-624e893e699a/b5e35934-1591-4543-a83e-5c2fa24b5e09_1101813726.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Cotes De Gascogne 75Cl",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "266958006",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/22880d13-c2cd-43f9-a39d-289404569d58/c61bb20c-2c87-4fe8-b01d-a8d8b860fab2_229923930.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687752",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Sancerre 75Cl",
    "region": "France",
    "price_eur": 22,
    "tesco_id": "261727766",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/44658877-f4e9-4870-be2c-275b50c26cab/46fedbd1-dfc8-4c5a-81bb-4b697660166c_893340636.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Falanghina 75Cl",
    "region": "Italy",
    "price_eur": 15,
    "tesco_id": "296829500",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7c162223-abd5-4ece-8d1b-b02b56a9bf31/612103cf-3169-4bf8-b603-02d509848d65_1705673273.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690343",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CALVET",
    "wine_name": "Calvet Chablis 1Er Cru 750Ml",
    "region": "France",
    "price_eur": 38,
    "tesco_id": "314710707",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/600117f8-cf95-4074-948c-bd589ef6ab13/71b83112-4497-4659-8c54-eab4c6e16cc1_2065154942.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TAPAROO VALLEY",
    "wine_name": "Taparoo Valley Australian Sauvignon Semillon 75Cl",
    "region": "Australia",
    "price_eur": 7.5,
    "tesco_id": "309765687",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/df9f6de9-fb58-4f43-ad98-284d68fb9057/b2b9aa1e-0fdb-4d9e-8a3c-4e9b0df4ce00_32049801.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DIABLO",
    "wine_name": "Diablo Volcanic Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "311943825",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1d95a905-fb86-4a76-95ac-f90a6ec11ad7/e000c30f-36bb-4a77-8bab-525390f2465e_127525595.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688515",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "JP CHENET",
    "wine_name": "J P Chenet Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "257439479",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/47ee5434-40d0-489e-ba65-882618c375b7/13dd544c-babd-4657-a3c1-3c4ef6cd6a9f_1052519997.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690452",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Chateauneuf Du Pape 75Cl",
    "region": "France",
    "price_eur": 27,
    "tesco_id": "254092414",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/81dacb0f-2612-4c73-be61-b82d76082795/9f2b108a-1f60-427b-ab1f-675e85e8ceea_1623219396.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Pouilly Fume 75Cl",
    "region": "France",
    "price_eur": 22,
    "tesco_id": "262426280",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1ffb4aa1-76f8-4af4-a751-2fd94f2add6b/21b68a88-061c-4123-aeeb-1de7aa86a552_1492759514.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Rivero Ulecia Utiel Requena Gran Reserva",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "317765738",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e2d6929e-d4fe-4846-b766-1fb45e679452/a22ce6e6-7fe7-48ac-8b19-420322724d45_385143837.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690342",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CELLIER PRINCES",
    "wine_name": "Cellier Des Princes Gigondas 75Cl",
    "region": "France",
    "price_eur": 25,
    "tesco_id": "309741577",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7fbb14f5-b280-4737-948e-223c93fd9cf5/7f6f4265-1994-45e1-b4c2-3da8d4446a76_1891844031.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690429",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€21.00/75cl",
        "offerText": "€21.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 25
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LOS CARDOS",
    "wine_name": "Los Cardos Chardonnay 75Cl",
    "region": "Chardonnay",
    "price_eur": 10,
    "tesco_id": "266550488",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dca800fe-ba4d-4dac-a4c6-2f6e876ebe24/bc1780ac-f88f-4793-b13d-db9a448ebe46_740444387.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688086",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OCEANS EDGE",
    "wine_name": "Oceans Edge Merlot 75Cl",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "266654475",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f1d6d10a-bfd8-4305-aa2f-ff5b9ff0af57/snapshotimagehandler_700459612.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690473",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Passerina 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "292542643",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bf2194c5-6d50-4fc4-9312-3deabde19b9d/1102770d-2be5-43a3-95ea-823eaa4abd50_2085724899.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687767",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SAN LORENZO",
    "wine_name": "Castillo San Lorenzo Rioja Reserva",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "256990990",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/384b7590-988b-4ea0-a526-a4f19cf172a3/3ef97304-4a98-495e-99ce-bd82e9d9e281_1502275249.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687742",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BEEFSTEAK CLUB",
    "wine_name": "Beefsteak Club Sauvignon Blanc 75Cl",
    "region": "Chile",
    "price_eur": 12,
    "tesco_id": "309761081",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8fdb27dc-4357-489f-8fe7-53c60e31c4fb/fa943fe9-e0f8-45e6-a866-55237af11bd5_1207429031.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690390",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CALVET",
    "wine_name": "Calvet Cahors Malbec 75Cl",
    "region": "France",
    "price_eur": 14,
    "tesco_id": "277043029",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/213d4d10-31bb-416d-a4b5-79100bb7ff17/snapshotimagehandler_617175625.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690351",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUES",
    "wine_name": "Marques Delatrio Tempranillo Rioja 75Cl",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "300735039",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e74c4617-6c25-4d2a-8781-4e35aa178adc/snapshotimagehandler_996092148.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690355",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "HARDYS",
    "wine_name": "Hardys Crest Cabernet Shiraz Merlot Red Wine",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "267787916",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9b2be629-467f-4712-8992-49cc900c5e7e/0f54c157-a9e3-4d50-9cd9-2dd530334791_527971151.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688335",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WHISPERING ANGEL",
    "wine_name": "Whispering Angel Rose 750ml",
    "region": "Rose",
    "price_eur": 26,
    "tesco_id": "314308531",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/89d35969-43fa-4355-b032-abdb624dadb0/87927c4e-41f0-4e28-b2c6-7ec1ffc4b505_1616486109.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Malbec Wine 75Cl",
    "region": "Argentina",
    "price_eur": 10.5,
    "tesco_id": "309457240",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1a9d8920-1a7e-4fa2-a607-885a7cf88cbc/a2a3d2d7-c460-4898-8e3f-7f9bdedb26fd_2142427611.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009369",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAMPO VIEJO",
    "wine_name": "Campo Viejo Rose Wine 75Cl",
    "region": "Rose",
    "price_eur": 12,
    "tesco_id": "304368899",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6fcb0fe0-2d92-46ed-a97e-0495215005ee/4b3064f2-5e5a-45f6-ac26-ce6f03a8273a_1489654609.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688418",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DIABLO",
    "wine_name": "Diablo Golden Chardonnay White Wine 75Cl",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "311802457",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/080ceaa3-b968-48aa-9628-23a83eee5d3b/a945e7a5-24a1-44b7-b36d-7655b200469a_237813733.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688513",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "19 CRIMES",
    "wine_name": "19 Crimes The Uprising Red Wine 750Ml",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "306954785",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b43893af-3a0a-41ce-bee0-7727317aa42a/8cb5ad4b-1599-45e3-82ef-f7edebbef8b0_1868705315.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687777",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VILLA MARIA",
    "wine_name": "Villa Maria Private Bin Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 13.5,
    "tesco_id": "251182290",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/897d9417-ddb6-4ba6-bb3e-e7e155d2fef2/ec0d6db9-d33a-41f3-ac21-2f5a7f21ba2b_1700883432.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688507",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MIRAVAL",
    "wine_name": "Miraval Provence Rose Wine 750Ml",
    "region": "France",
    "price_eur": 30,
    "tesco_id": "304791628",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/316de76c-5644-4f8d-a5f3-811d86a2d61a/948a359a-3739-4e29-b2a3-b742d4de7ef1_1657960658.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BLOSSOM HILL",
    "wine_name": "Blossom Hill White 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "259712953",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/017b7eb6-dac9-485d-a190-0d3d3d256ff6/686b1afa-0213-4d37-a8f4-f46b8ae976e4_1328196433.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BELLA CUCINA",
    "wine_name": "Bella Cucina Prosecco Frizzante 75Cl",
    "region": "Prosecco Sparkling",
    "price_eur": 12,
    "tesco_id": "301768466",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/90c44c6a-3133-4004-a47d-8778df872053/5f1ee5bc-9cf4-4bd1-8815-5f6cc779077b_1841042035.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690460",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Dadá",
    "wine_name": "Finca Las Moras Dada Art Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 10.5,
    "tesco_id": "296350466",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/78641611-1cef-413d-8845-191cba15287a/e0cc3902-4142-4939-8f26-1b496366027c_812088615.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961756",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "AMANTI",
    "wine_name": "Amanti Prosecco Frizzante 75Cl",
    "region": "Prosecco Sparkling",
    "price_eur": 8,
    "tesco_id": "290694932",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/edadfde7-abfd-403b-b281-0d37655bafe0/snapshotimagehandler_1099633587.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GRAHAM NORTONS",
    "wine_name": "Graham Norton's Own Prosecco Frizzante 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 12.5,
    "tesco_id": "302797239",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a8d7fc78-231d-440a-8f89-5b502a1b2567/8ea4cc11-7b03-47d8-96af-2fd73f28cf29_1551040582.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690362",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VALLADE",
    "wine_name": "Vallade Gavi Docg Wine 75Cl",
    "region": "Italy",
    "price_eur": 14,
    "tesco_id": "286703779",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8c0d9050-b5d3-4a24-a700-94244e61c528/b015f1d6-09df-4378-a471-cb9b27cda74f_324927012.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687764",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GRAHAM NORTONS",
    "wine_name": "Graham Norton Sauvignon Blanc",
    "region": "Sauvignon Blanc",
    "price_eur": 15,
    "tesco_id": "295432878",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f0f671de-f2a4-4865-ba69-3ad0f03bf5ee/d1f833d0-f398-41e1-a0e8-2ce29809f6d9_789544874.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914874",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PEPPERBOX",
    "wine_name": "Pepperbox Shiraz Wine 750Ml",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "309163944",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5fe78264-a185-41c6-80b8-efbd4d6b0d77/7d65786e-d692-4f0e-b825-b04981a21931_1050229935.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959413",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MUD HOUSE",
    "wine_name": "Mud House New Zealand Sauvignon Blanc White Wine",
    "region": "New Zealand",
    "price_eur": 13,
    "tesco_id": "283840321",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e0c8d138-79fd-45b3-a200-e6ab8d007b5e/7fc41307-3a1d-42a5-a6b0-4efbce77ee84_1375105532.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687762",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PROSECCO FRIZZ",
    "wine_name": "Prosecco Frizzante Borsari 750Ml",
    "region": "Prosecco Sparkling",
    "price_eur": 12,
    "tesco_id": "295037230",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/44e7e0c6-8c1b-4e20-9ade-e8baacdcd5a7/snapshotimagehandler_116859645.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690419",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Il Capo Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 7.5,
    "tesco_id": "278935902",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b13cade4-207f-4a69-bb70-3cb9f2d4b5fc/bc4d0510-ba39-4023-a1e6-e85597c9f8ef_525055231.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TORRES",
    "wine_name": "Torres Vina Sol 75Cl",
    "region": "Spain",
    "price_eur": 10,
    "tesco_id": "255244194",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c82715e3-c30b-45bb-bf50-c0a3602d07b4/417b488f-0616-4599-9af9-f42c3e1922e8_1207179844.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91908848",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MASCHIO PROSECCO",
    "wine_name": "Maschio Prosecco 3X200ml",
    "region": "Prosecco Sparkling",
    "price_eur": 11,
    "tesco_id": "294901348",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/394d4d79-b09c-45a3-bb1c-fdcb8af7973f/snapshotimagehandler_867633620.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "KUMALA",
    "wine_name": "Kumala Reserve Sauvignon Blanc White Wine",
    "region": "South Africa",
    "price_eur": 12.5,
    "tesco_id": "296631226",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/143a7d54-338d-424a-b4b8-8485d31b2093/a4846206-35cd-46b3-ae45-c74b28db6e59_450473736.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690371",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Chardonnay 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "251295853",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/331b9c97-fa37-48be-82f9-a0813e08caba/149b64a6-c009-4916-bf8c-6e580703e255_2036447892.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914324",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA BRUNAUDE",
    "wine_name": "La Brunaude Syrah 750 Ml",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "267051416",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f8103c9b-4893-4926-bf6c-3485ac400d58/snapshotimagehandler_1502596731.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690366",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA BRUNAUDE",
    "wine_name": "La Brunaude Sauvignon 750 Ml",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "267051150",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ee0b8457-acdb-4044-86bd-00ad6f29ce5b/snapshotimagehandler_1089284289.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690416",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LUSSAC",
    "wine_name": "Lussac St Emilion750ml",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "268774992",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3c9162f6-bc61-4b7a-a135-ed46d7734946/fb42ecb2-16d7-4cd9-b565-2de55e9256c9_1084825843.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690456",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TRIVENTO",
    "wine_name": "Trivento Reserve Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 11,
    "tesco_id": "278363743",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9c25200a-dfc9-4b0e-a69d-297ac3b4692d/49c4f0ba-e7a4-48c7-9b3a-4f485dd1ca53_1229886263.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688392",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 11
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Cabernet 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "254820850",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c7dc9ef5-3f5c-4199-81d6-c9e077230678/10dfc640-74ac-4e2a-81d6-6db2734c2b12_53586242.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688084",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ISLA NEGRA",
    "wine_name": "Isla Negra Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 16,
    "tesco_id": "256267770",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fa835eb4-ca57-46a0-aefe-6b655907644c/a2a672d9-1a1f-4917-bdfa-7da2776966b4_1248254072.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690457",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Classic Pinot Grigio 75Cl",
    "region": "Pinot Grigio",
    "price_eur": 17,
    "tesco_id": "264485211",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b6c4e067-cb31-480f-afd1-8cb2098c354d/c4387953-2e95-4b7b-9d44-e9ea552a7b7a_1861510989.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "19 CRIMES",
    "wine_name": "19 Crimes Sauvignon Block Sauvignon Blanc 750Ml",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "306501158",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/49d4eca5-7cb3-4e85-a738-33b39dd7da35/9f3f742c-c5c2-4951-a718-cef5ab2bf2b1_837434544.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688512",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Merlot 187.5Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "274699300",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9a689d00-b28c-499d-92ef-4408ad3cfd75/snapshotimagehandler_42456754.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Sauvignon 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10.5,
    "tesco_id": "250289753",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c1914df3-21a6-4894-9642-32857bf3fb88/1a4dbd4f-f9d4-4063-b27b-d4008360cf71_1709906025.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690410",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUES",
    "wine_name": "Marques De Caceres Crianza 75Cl",
    "region": "Spain",
    "price_eur": 15.5,
    "tesco_id": "285615349",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c77745d3-8e25-430b-8d89-797a5c62b18a/a92eea44-d778-4065-963e-cbd3fc08e813_65144062.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688021",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "THE GUV'NOR",
    "wine_name": "The Guv'nor 750Ml",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "300472552",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/51e24427-8050-439a-a99b-11cf53ed70fb/34f81e98-ffa5-4492-a48f-513673c79418_2047047599.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690449",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FINCA",
    "wine_name": "Fincas Las Moras Dada 1 75Cl",
    "region": "Argentina",
    "price_eur": 10.5,
    "tesco_id": "289647898",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/028ffa72-1f65-4bdc-8d77-575ed064379c/52c9bfd4-acb2-4db1-87a5-14bf2b373d42_384879672.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961755",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Vii Rioja 75Cl",
    "region": "Spain",
    "price_eur": 13,
    "tesco_id": "250322893",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/78058828-1fc3-4f27-92df-100404c4d60e/b2e63c17-111b-4952-b4a4-fd978e3c3dc3_1322456136.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688407",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CHAIS DE BOURLEMONT",
    "wine_name": "Chais De Bourmnt Cotes De Duras Red 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "284658933",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/62ec1005-e50d-4a0d-b56d-1baf8e520e6a/snapshotimagehandler_594556186.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690433",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Tempranillo 750Ml",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "307135250",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7203a43b-1459-4960-8708-a6efd4a8f480/snapshotimagehandler_404600318.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690407",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WOLF BLASS",
    "wine_name": "Wolf Blass Eaglehawk Chardonnay 75Cl",
    "region": "Chardonnay",
    "price_eur": 12.5,
    "tesco_id": "253229331",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c839e16b-bd76-406f-b272-70e4f733237e/8f221e78-a4b7-4466-9aa7-52e2945ccd99_758383700.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687999",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Prosecco Frizzante 75Cl",
    "region": "Prosecco Sparkling",
    "price_eur": 11,
    "tesco_id": "296239772",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/99a7660e-b7b3-4ffe-90e3-3fc32c4ec576/be443d70-0e59-4f75-b1e4-9fd866078e99_995465661.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "[ yellow tail ]",
    "wine_name": "Yellow Tail Pinot Grigio 18.7Cl",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "285299852",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dfc8f4f5-41b2-4cb9-837f-35b0d1b8c59b/25d193fe-a3ce-4c05-86e7-b732d4c96c4c.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GRAHAM NORTONS",
    "wine_name": "Graham Nortons Vino Frizzante Rose 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 13,
    "tesco_id": "307734042",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f73af335-8717-4b20-a4af-811c1645405d/f87ca331-6d63-4c09-80b6-72b3bb285d30_224961229.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690485",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Cabernet 750Ml",
    "region": "Cabernet Sauvignon",
    "price_eur": 10.5,
    "tesco_id": "265815051",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4d8a1c40-d976-470f-a06c-8bc291de52c6/8822f70f-81c4-4aa8-ba7a-f5af82586a46_1476994845.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690438",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Bicicleta Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "253412592",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4dab44fd-bcf6-4b0d-9b90-17d0c70dcf09/01f69adc-53e7-48b9-8265-ff88b5c458f5_2072036209.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688149",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Prosecco Rose 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 18,
    "tesco_id": "306655269",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0df7f44f-8907-4317-ac4d-4e24b1a96fe6/7960bd68-9c41-4e0b-a8b7-0294d85ddb66_1595974383.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688505",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€15.00/75cl",
        "offerText": "€15.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Pinot Grigio Blush 75Cl",
    "region": "Rose",
    "price_eur": 12,
    "tesco_id": "304411671",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8911e80a-850d-4e2f-93d6-8530f5b3078c/0ca90571-0b74-4f83-a020-471377419b08_1863544683.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690372",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Malbec 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "274261812",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6c6a7688-0f39-413b-bfd5-66fb4af359b7/ec2ed5ff-c19c-4704-9c83-bcaf52ad5f32_1822720406.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914325",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Steep Slopes Mosel Riesling",
    "region": "Other",
    "price_eur": 12,
    "tesco_id": "255819557",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e36308ad-1f2f-4434-92c1-3814b67c0f1a/d1bdec3e-f010-444f-953f-c52916b30561_1204721364.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690424",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "HARDYS",
    "wine_name": "Hardys Crest Shiraz Red Wine",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "293657477",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/16175a8b-318d-468e-a1ae-959461f18670/c7db8532-8283-42c1-bd0a-645a4a260001_752579277.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688332",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FERN BAY",
    "wine_name": "Fern Bay New Zealand Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 9,
    "tesco_id": "310685279",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e4d10d6b-06a3-4e12-ac93-1ac2669bf836/7f8dcb52-33ec-48a8-8689-99c4a4b2fcf2_1030680636.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "[ yellow tail ]",
    "wine_name": "Yellow Tail Shiraz 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "262272190",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9f52bf38-4ddf-4201-89c3-12a7138d5326/692192c4-f07f-4ec0-81e8-d669af06b601_371218644.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959329",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Pinot Grigio 187Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "289999757",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/003d5854-dcb2-4d86-9aee-ec2e74f9398e/16789464-1dd0-4e83-994d-fb31fc6f59f0.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot White Zinfandel 75Cl",
    "region": "California",
    "price_eur": 10.5,
    "tesco_id": "266182854",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e528c307-9e20-4ca7-be0d-b0921179ef41/f8771d6b-da50-485a-8afb-3ce239510c79_1803854510.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688106",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 10.5,
    "tesco_id": "283909190",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7e17ed8b-55d7-4721-b35f-dd90e4e6bade/2d1a81f7-944e-4ac7-8cbc-281e84c1101c_2006137745.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009368",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10.5,
    "tesco_id": "277016707",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4f96c4ff-0c3b-4a8d-a9e1-02011d60ab9a/37c79376-3b04-4933-ac75-953ba8aa4bdf_219476078.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688111",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MATEUS",
    "wine_name": "MATEUS ROSE 75CL",
    "region": "Other",
    "price_eur": 11.5,
    "tesco_id": "255245360",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6e074e16-361b-4aa5-9179-38cc13f282f8/733b1b77-8b54-480d-b3b8-58fea8c2d71d_1951703413.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687738",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 11.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Valpolicella Ripasso 75Cl",
    "region": "Italy",
    "price_eur": 15,
    "tesco_id": "295211063",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cf0f146c-439d-41ab-a1eb-cf31a6ccf542/13f823a3-e35a-4507-9304-3741c4c4a54b_565680164.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687769",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WAIRAU COVE",
    "wine_name": "Wairau Cove Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 13,
    "tesco_id": "259738433",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6a4a4f34-b189-4a76-b036-fd5d31771bbd/8da40eab-fa45-4f9c-93a3-5a7b1da9f5fc_598547137.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687746",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LACHETEAU",
    "wine_name": "La Brune Chardonnay 75Cl",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "278936849",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bad94ec8-682f-4596-9620-773007538741/c32b604b-c824-4e1c-9a40-c75076398634_1390959698.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690364",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Merlot 75Cl",
    "region": "Merlot",
    "price_eur": 10.5,
    "tesco_id": "255417854",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4819ceca-f329-42f5-8bb2-cf17c7a89124/dd0a4233-8212-4fc7-829f-0c34d872630c_219797249.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688107",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita Merlot 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "254828853",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/132e40d9-abb2-4798-9e84-473a5c40cd36/8d5ed9a4-b949-49a0-b7e6-3957c41d00a4_1718367502.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688078",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Ruby Port 75Cl",
    "region": "Other",
    "price_eur": 12.5,
    "tesco_id": "255247156",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7ec64116-89ff-4396-a5a7-ebe12ad86276/56212c1d-99f6-4bbd-8e52-0070e465b939_1031513054.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CUNE",
    "wine_name": "Cune Crianza 75Cl",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "288408319",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b01632b4-e618-4040-9fb0-fa15f733fbad/snapshotimagehandler_1291522050.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914817",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "[ yellow tail ]",
    "wine_name": "Yellow Tail Shiraz 18.7Cl",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "285300825",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/374d0e1e-8548-4c13-a443-13db884af64a/e509dab4-b68a-4dcb-be29-f841b3b40423.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "ELMSTONE",
    "wine_name": "Elmstone Marlborough Sauvignon Blanc",
    "region": "New Zealand",
    "price_eur": 14,
    "tesco_id": "317641401",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7a602f3b-6e7f-4543-8335-20111a3575c3/6db4c5d5-9fe1-45c1-b259-357be2becc97_839258723.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687992",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Malbec 75Cl",
    "region": "California",
    "price_eur": 10.5,
    "tesco_id": "290266980",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/60d567dd-b0a6-407d-b7b9-7a98965749f0/2073e5fa-32c0-45a3-b492-8281810c4337_923317834.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688114",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BLAUMEISTER",
    "wine_name": "Blaumeister Liebfraumilch 75Cl",
    "region": "Germany",
    "price_eur": 6.5,
    "tesco_id": "311806317",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b105ffa4-c049-40d7-b91b-d65dd09225cb/4b16d408-9610-4607-bbfe-4b3a73e1b3f2_1678200936.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "WOLF BLASS",
    "wine_name": "Wolf Blass Eaglehawk Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 12.5,
    "tesco_id": "287207357",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4f5c80aa-17d6-4e98-978c-ee77789c4202/snapshotimagehandler_1723391634.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688003",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GRAHAM NORTONS",
    "wine_name": "Graham Norton He Devil Rich Crafted Red 75Cl",
    "region": "Argentina",
    "price_eur": 13,
    "tesco_id": "311431072",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8a997c98-6695-42e9-bcd5-44ab6381195b/05719def-f2ed-49e5-a4f3-feb8d75680d5_1167291693.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688036",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SACCHETTO",
    "wine_name": "Sacchetto Prosecco Snipe 20Cl",
    "region": "Italy",
    "price_eur": 3.75,
    "tesco_id": "286416497",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/518bc71d-b6f1-454e-8368-6d37beca189b/snapshotimagehandler_1692453937.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "WOLF BLASS",
    "wine_name": "Wolf Blass Red Label Shiraz Cabernet Sauvignon 75Cl",
    "region": "Australia",
    "price_eur": 13.5,
    "tesco_id": "255858412",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bb72fd27-6d31-44f5-b765-f60cacf5eecc/656e49e5-9c50-4fa0-904e-a136de63123c_1997976331.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688160",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TAPAROO VALLEY",
    "wine_name": "Taparoo Valley Australian Chardonnay 75Cl",
    "region": "Australia",
    "price_eur": 7.5,
    "tesco_id": "309770191",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2ee4c51f-a208-4991-af25-f69fc7402418/1b05ad4a-c9e8-4db3-a604-b3a640df4f87_685024633.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Merlot 187Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "290012750",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3df2225a-9602-4112-8d34-2bf0bd9f6393/49f37304-6f74-4bdd-ac6e-8ea7454d06b6.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "EL RASTRO",
    "wine_name": "El Rastro Red 75Cl",
    "region": "Spain",
    "price_eur": 17,
    "tesco_id": "306812458",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bf2dd824-3474-4ce0-ac7b-c0795b4b3889/b8fe161d-7254-40ca-9a8d-cd3af71fe7f8_588856367.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690477",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Merlot 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "251984268",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e8b455a4-e49b-4990-9f79-5bc662b5471d/87e6e62d-93bf-4510-9e2d-6ffb1a5ddbf4_551875659.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688164",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Cabernet Sauvignon 18.7Cl",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "268742771",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e74d14fa-4387-43f4-bc5a-f08b84da61cc/773a35a6-1e49-4778-b680-85bcb3c0a710.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BEEFSTEAK CLUB",
    "wine_name": "Beefsteak Club Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 12,
    "tesco_id": "306822884",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7e255dd8-a5a0-47f8-a1be-ed71e8ad5ef6/ede7c1fd-1fa7-4d37-9fbd-b45f2cc95206_1009408123.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690382",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CARMEN",
    "wine_name": "Carmen Insigne Sauvignon Blanc 750Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "286811720",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/43203d16-d840-40e0-a4da-2dc180359189/snapshotimagehandler_508055623.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688099",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Monteforte Pinot Grigio 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "296394206",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1538a416-8153-4dca-a01a-ff070d326cdb/7b66a187-c76d-46a3-973b-d1162037eb7c_84015446.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690437",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Red 750Ml",
    "region": "Australia",
    "price_eur": 10.5,
    "tesco_id": "300455446",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/05330f95-cf80-41a5-a0ce-1f87afcc1cb7/2820c60b-7b79-43e3-bead-912b2f0fb008_993918230.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690447",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VIGNOBLE BEAUBOURG",
    "wine_name": "Vignoble Beaubourg Languedoc 75Cl",
    "region": "France",
    "price_eur": 19,
    "tesco_id": "314828036",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fecff029-037b-4028-8bf1-6deaca4a00db/7fea1cb2-e6d1-4a28-83f8-760387559346_664723760.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690402",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUES",
    "wine_name": "Arianzo By Marques De Riscal 75Cl",
    "region": "Spain",
    "price_eur": 20,
    "tesco_id": "276131733",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2be47e66-6893-44df-bb6d-43d6f2d46903/5a2de7ad-51ea-435c-9e6d-092557554f3d_185748223.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687758",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LOS CARDOS",
    "wine_name": "Los Cardos Sauvignon Blanc 75Cl",
    "region": "Sauvignon Blanc",
    "price_eur": 10,
    "tesco_id": "266550592",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2a84f91c-e232-49d5-8c81-e6472592586a/feb13ef4-634f-4729-a562-5f439f324b43_1316744920.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688081",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards Pinot Grigio 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "264456782",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1087e237-ae90-4a0a-891d-258ac7e0163d/b84bfb02-c799-402d-b41c-3720bdb59ebb_746750040.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Argentinian Malbec 75Cl",
    "region": "Malbec",
    "price_eur": 12,
    "tesco_id": "264534413",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e6b88c66-14c6-4f79-9313-60d14f406d92/87df72df-a4a1-4909-a935-26e0fbf940e1_193894075.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687745",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DIABLO",
    "wine_name": "Diablo Red Blend 750Ml",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "299042348",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/01d2eaaa-d509-494e-b0d0-d0c2505d463e/fd00f8cd-5cfe-4000-a6fd-0ef275ab7709_1304416850.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688508",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BLACK TOWER",
    "wine_name": "B By Black Tower White 5.5% 750Ml",
    "region": "Germany",
    "price_eur": 5,
    "tesco_id": "281362354",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fade8067-0c68-4d56-b443-51b93d495daa/snapshotimagehandler_1684619790.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BLACK TOWER",
    "wine_name": "Black Tower Pinot Grigio 75Cl (C)",
    "region": "Other",
    "price_eur": 8,
    "tesco_id": "260064819",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a39f1862-c604-4d6f-b40d-38b97f750f89/fc876257-62da-4aa8-ad72-9bcc0f9ca4a5_1916155735.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Sauvignon Blanc 75Cl",
    "region": "California",
    "price_eur": 10.5,
    "tesco_id": "292632462",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/98c56673-f0ee-4a54-a434-d1d1155df815/af33f258-bc69-4b94-beda-f2fa30c2a86d_2124347681.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009370",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VIGNOBLE BEAUBOURG",
    "wine_name": "Vignoble Beaubourg Corbieres 75Cl",
    "region": "France",
    "price_eur": 19,
    "tesco_id": "314699510",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/72b59344-8d60-4b26-b7bc-79087d4f9509/3b8593fb-42f7-47d2-a1cd-34b7a3038097_356691545.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690383",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards White Zinfandel 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "256564781",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e48ef1f0-beb0-4a90-a8e5-50d1a3bb48d6/720cfced-b579-453d-a62f-c37d3c639a8f_1365734980.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Pecorino 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "280145052",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7c4eeae3-b836-4754-aa02-ed50ee7a4f02/ce97c63a-f231-468b-ae95-3c05186d91ff_1456543090.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687761",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Ah,",
    "wine_name": "Ah, Sauvignon Blanc 750ml",
    "region": "Spain",
    "price_eur": 18,
    "tesco_id": "321668842",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/04c0fcbd-bdc6-43b6-9fdd-8f1331680594/ababcdfb-cfdd-4457-8c98-15f39372c9d1_1436224290.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91932042",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€13.00/75cl",
        "offerText": "€13.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MOET & CHANDON",
    "wine_name": "Moet & Chandon Imperial Brut Champagne",
    "region": "Champagne",
    "price_eur": 62,
    "tesco_id": "255245509",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8c99f67c-c4d7-427b-9246-26db06493074/1b2dd065-e99a-48da-90fb-20088ef3d5d7_1969046146.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "FREIXENET",
    "wine_name": "Freixenet Cordon Negro Brut Cava 75Cl",
    "region": "Spain",
    "price_eur": 22,
    "tesco_id": "257182735",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d273f425-e278-4241-b6a4-71fefff12abc/c772cad4-c650-4232-a73e-cdd2df411270_929901283.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688162",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€18.00/75cl",
        "offerText": "€18.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 22
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "19 CRIMES",
    "wine_name": "19 Crimes Australian Chardonnay 75Cl",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "301786634",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/58967338-7cf6-45d2-8187-60f77e9fb635/c36adaf7-caaf-40f6-bde0-e2d365daf637_425442825.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688510",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Cream Sherry 1L",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "255246451",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/81dfe2cd-5d7e-4abf-8956-7ce378454ede/0fb0614e-d75f-4e85-b9df-8970152cfe23.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Pink Moscato 75Cl",
    "region": "California",
    "price_eur": 10.5,
    "tesco_id": "276938810",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4c8747a7-0542-4903-8b2c-4225869976a9/b638452e-027d-45eb-baf6-8c12e47d828c_113112583.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688113",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MOST WANTED",
    "wine_name": "Most Wanted Albarino 75Cl",
    "region": "Spain",
    "price_eur": 16,
    "tesco_id": "297425613",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3271a548-ce6e-4dcc-a18e-71ddb9dacfa1/f2e46340-7915-4271-b984-aea7a0bfe3c7_1325435383.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687771",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€14.00/75cl",
        "offerText": "€14.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Carmenere 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "256999306",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/efa6bc57-6345-45a7-a7fc-819e4bf3cfb0/5a4579cb-5da9-47a0-a8f3-e7ab511757ad_1728602477.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914329",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "YEALANDS",
    "wine_name": "Yealands Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 15,
    "tesco_id": "313746900",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0580c08c-7f77-4949-ac1c-b2ac74c5fd89/250e3286-4899-4ecd-a3ec-8835b3decfb6_1592071680.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688516",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LATERAL",
    "wine_name": "Lateral Chilean Merlot 75Cl",
    "region": "Chile",
    "price_eur": 7.5,
    "tesco_id": "309450155",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0cf2161c-e451-4c50-bb04-e3fa9855b833/6080fbec-4154-400b-af14-b9e6ce727383_884471599.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BRANCOTT ESTATE",
    "wine_name": "Brancott Estate Flight Sauvignon Blanc 750Ml",
    "region": "New Zealand",
    "price_eur": 14,
    "tesco_id": "298579348",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2c74c5b2-0f4e-4e85-bd90-9125e8e184fd/b176a86f-33a3-4582-9177-b87d6d9dab6b_76782512.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688309",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "EAGLE HAWK",
    "wine_name": "Eagle Hawk Cabernet Sauvignon 75Cl",
    "region": "Australia",
    "price_eur": 12.5,
    "tesco_id": "257785460",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bbb335c1-738b-4fa9-81fc-5c325c24f95f/04674917-a9f7-45bf-8574-eb2cf2265ffe_35038394.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687994",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CARANO",
    "wine_name": "Marques De Carano Gran. Reservado 75Cl",
    "region": "Spain",
    "price_eur": 13,
    "tesco_id": "259738807",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/02c186a9-1f55-43ca-a2bb-537993c85602/4bbac268-8fc4-4e79-ba13-75fea5a734ba_1184589636.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690341",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "KYLIE MINOGUE",
    "wine_name": "Kylie Minogue Frizzante Rose 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 15,
    "tesco_id": "310138571",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3ce68e25-ae44-41dc-a136-a5eb66df7c47/7e1ec564-df91-4a3e-a240-62d888009707_470136320.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690467",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DIABLO",
    "wine_name": "Diablo Purple Malbec",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "317208881",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/aab82365-dfea-4178-b116-f61b871484fe/9a21341e-e102-4d01-bf1f-86599d42d236_1871494921.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688517",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PORTA",
    "wine_name": "Porta 6 Vinho Verde White 750Ml",
    "region": "Other",
    "price_eur": 13,
    "tesco_id": "314317747",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/644c9fdd-5edd-4da0-b3f3-a17aa5fc2254/40fa1d6a-6f15-47a5-81c8-ee5ea1d8a7b1_339526220.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690388",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MAISON DU VIN",
    "wine_name": "Maison du Vin Picpoul de Pinet",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "317747812",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2032507d-2887-4450-b310-0027a0f9b63f/3c3040ff-92f6-45b4-867f-ffc332a3198c_719830010.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687862",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "McGuigan Classic Shiraz Cabernet",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "317530279",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4711f214-579c-49c1-b664-0b4c456a1338/c6699741-f5ad-4234-bd28-2699c16172e6_1790992105.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Picpoul De Pinet 75Cl",
    "region": "France",
    "price_eur": 11.5,
    "tesco_id": "267931157",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b2160a84-f671-4ce6-a150-31e75e919ad3/4421be4e-e5e7-4194-9e59-8f8b9aa24cc7_2054937412.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "VISTA CASTELLI",
    "wine_name": "Vista Castelli Montepulciano Dabruzzo 75Cl",
    "region": "Italy",
    "price_eur": 8,
    "tesco_id": "310670924",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/72a7e0cc-a82a-4e32-9075-5a98bc206bbd/eb6b9528-4818-4726-b805-3081c3d3b512_1843586180.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Primitivo",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "309499005",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ce326c27-4bb5-45e0-8a9d-911a95261ea0/90f2ef52-c223-4c08-971b-2680b4f7eba7_1527403251.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "OCEANS EDGE",
    "wine_name": "Oceans Edge Cabernet Sauvignon 75Cl",
    "region": "Australia",
    "price_eur": 17,
    "tesco_id": "266652696",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f389cfac-c9fd-4aad-84f2-d21a3e18d011/snapshotimagehandler_133131345.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690414",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CHATEAU MOULIN",
    "wine_name": "Chateau Moulin Du Rey 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "314110401",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cec71cab-a0bc-4467-b5f0-09c0120535f5/ea84faae-0c32-49cb-8b6e-6c8088810af4_1690256705.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690348",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OTE",
    "wine_name": "19 Crimes The Banished Dark Red 75Cl",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "299531363",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/53bccd2f-f428-4d3d-87ea-510374fb08b8/66fa1648-7028-49bc-8468-e2a2326ce16f_827017906.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687773",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CALVET",
    "wine_name": "Calvet Heritage De Calvet Cotes Du Rhone Villages",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "278418150",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/598cea5c-b7e3-4c94-8ac5-5d3fd4a40b8e/cebdd507-6096-4f37-817f-ba58904d35b4_237564347.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687759",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "DARK HORSE",
    "wine_name": "Dark Horse Chardonnay 75Cl",
    "region": "California",
    "price_eur": 12.5,
    "tesco_id": "283170900",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9cd4ebf1-55a6-4406-84e1-613fc9558139/e97a103c-5a36-45af-a80d-d2a231921d05_1445603319.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688051",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Gavi 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "257238803",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d8491cff-5bae-489d-a029-25446c9f58b4/6697cf34-431a-447a-a041-ac11dd6776c0_1683153816.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Vinas Del Rey Albarino 75Cl",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "262557389",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/87efaf68-9c9a-462b-a179-9471e83408c9/bb220a4a-cfc9-4539-a25f-ce0f1db0fc45_1896907699.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CALI BY SNOOP",
    "wine_name": "Cali by Snoop Red Wine 750ml",
    "region": "Other",
    "price_eur": 17.5,
    "tesco_id": "310128024",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/539a0c7d-3ec2-4a46-a99b-b9149bc38004/6fdce87b-dbf5-437b-bdfa-1d888c7bcd95_1643448129.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91908851",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€15.00/75cl",
        "offerText": "€15.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BLACK TOWER",
    "wine_name": "Black Tower Fruity White 75Cl",
    "region": "Other",
    "price_eur": 8,
    "tesco_id": "255243120",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/650356eb-503f-4758-8388-67d78bc00aa5/7cd03e03-e0cb-4114-aa04-83288c206f48_169627753.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards Merlot 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "251678389",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/81bfd6b2-c8b8-4655-8ae5-40671bd74ad1/8cfc4467-b8ab-45b6-a48e-eee03aedfe2f_1823859727.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "Black Tower",
    "wine_name": "B Secco White 75Cl",
    "region": "Low Alcohol",
    "price_eur": 5,
    "tesco_id": "290538151",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d8e3337a-bad7-42eb-a3f7-17be9d93d0e4/snapshotimagehandler_1378671876.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BAREFOOT",
    "wine_name": "Barefoot Buttery Chardonnay 750Ml",
    "region": "North America",
    "price_eur": 10.5,
    "tesco_id": "312110107",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/91ced953-846c-4c41-b298-9b56cdc9daf3/afe13187-e9af-486c-9e80-b826160c497e_1730173585.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688112",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CUNE",
    "wine_name": "Cune Cava 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 18,
    "tesco_id": "295648750",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/72b3c4c7-2020-4d23-a841-3f06f2eff87e/snapshotimagehandler_2057116818.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961796",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€16.00/75cl",
        "offerText": "€16.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CALVET",
    "wine_name": "Calvet Cremant De Bordeaux Brut 75Cl",
    "region": "France",
    "price_eur": 22,
    "tesco_id": "314701595",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0719998f-b819-450e-a605-b5e6bab9d6bd/9e463e7a-2528-4286-9dac-126a4c80ee8c_1431120558.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687828",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€18.00/75cl",
        "offerText": "€18.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 22
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Del Diablo Shiraz 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "261058238",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/155874ea-141b-4b56-9620-ffdab07035fc/f85bfb6c-f013-49b2-8868-1dc5b3496910_2104377655.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91914323",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "EAGLE HAWK",
    "wine_name": "Eagle Hawk Wolf Blass Merlot 75Cl",
    "region": "Australia",
    "price_eur": 12.5,
    "tesco_id": "253228741",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ef52e198-79d1-423d-9a89-16894bafeddb/snapshotimagehandler_1838903214.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687998",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "A WINTERS TALE",
    "wine_name": "A Winters Tale Sherry 75Cl",
    "region": "Other",
    "price_eur": 15.5,
    "tesco_id": "250835614",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/eca9486d-8876-4c63-8297-a7f64e8ad0b0/d2bf8500-10da-47e5-a466-99fd1b6ecd80_1623259110.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Vii White 75Cl",
    "region": "Spain",
    "price_eur": 13,
    "tesco_id": "250322956",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9f49316b-9e3d-4d61-9f18-c81c1cc7ddf2/snapshotimagehandler_637241117.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688405",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Bicicleta Pinot Noir Rose 75Cl",
    "region": "Rose",
    "price_eur": 10,
    "tesco_id": "307360495",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4e8a0604-b0bc-4841-91ce-1c551abe9873/snapshotimagehandler_1442882726.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688155",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CARMEN",
    "wine_name": "Carmen Insigne Chardonnay 75Cl",
    "region": "Chardonnay",
    "price_eur": 10,
    "tesco_id": "287887795",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c8dcda35-f8d8-47de-aabb-bbfa655aadbe/snapshotimagehandler_1928952518.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688101",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Sauvignon Blanc 75Cl",
    "region": "Argentina",
    "price_eur": 10,
    "tesco_id": "255244862",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5988f8fa-a6a8-4a63-b17e-f074278881cd/56cb4af5-92a3-4275-8ea2-f736a564f3d2_964863917.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CANTI",
    "wine_name": "Canti Prosecco Frizzante",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "317862295",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6b77ba9c-9695-4ee5-8715-f3678c909264/5a4468a6-bbfe-4d68-9843-d7eaf71bee21_784331415.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690370",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SJP",
    "wine_name": "Sjp Marlborough Sauvignon Blanc 750Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 15,
    "tesco_id": "309786748",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/06c3396f-efe6-449a-bf84-33eb6df4c582/898d2e9f-f640-454d-b515-5fc78c061588_1918289674.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688555",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-05T23:00:00Z",
        "unitSellingInfo": "€13.00/75cl",
        "offerText": "€13.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OYSTER BAY",
    "wine_name": "Oyster Bay Chardonnay 75Cl",
    "region": "New Zealand",
    "price_eur": 13.5,
    "tesco_id": "266636059",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fd949bd2-637e-456b-a7de-16827ec53ca5/d7b680a5-6555-4622-a526-0a5d9ab715f4_756749859.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91924461",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "[ yellow tail ]",
    "wine_name": "Yellow Tail Merlot 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "262271605",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b3b8fbd5-b853-4fe2-bf66-3198e0014b43/ce513355-2c4a-42b2-99da-3c144a417ec2_460911895.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959445",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita Reserva Rose 75Cl",
    "region": "Rose",
    "price_eur": 10,
    "tesco_id": "300422733",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fa345562-f519-4239-a4fe-89fb70aa356f/snapshotimagehandler_256940485.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688080",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "AASANI",
    "wine_name": "Firemark Argentinian Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 7.9,
    "tesco_id": "309478899",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6ec258f8-21b0-4e57-ad93-8372ae80198b/6e2cfc02-5f0a-439e-a11f-fa4c24093e76_74173813.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Organic Sauvignon Blanc 75Cl",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "304696223",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/53203ecc-a2da-409b-8aeb-a2a2e1e3392e/51c80076-3c28-4d4b-b0ef-f45989a910e4_562260344.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688005",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANDEMAN",
    "wine_name": "Sandeman 5 Star Port 75Cl",
    "region": "Other",
    "price_eur": 20,
    "tesco_id": "256271597",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/700cd4d3-4fdd-449d-93c7-00816aa655af/c3fc8ff3-6654-4f54-9f94-50bbc82de8b8_859799620.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DARK HORSE",
    "wine_name": "Dark Horse Cabernet Sauvignon 75Cl",
    "region": "California",
    "price_eur": 12.5,
    "tesco_id": "283170860",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4e9d2522-674e-46cf-834e-36a2f0c1f4b5/1861fd2a-3eed-4f89-b49b-78350b582472_746596322.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688050",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Rivero Ulecia Reserva Rioja 75Cl",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "300734888",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/31c0c9be-3182-4c8a-846e-aecf180d6abd/snapshotimagehandler_2036581639.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690420",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 De Alcoholised Cabernet Sauvignon 750Ml",
    "region": "Wine",
    "price_eur": 5,
    "tesco_id": "311665889",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5063410d-b4c8-45e7-8171-cfb8cb7bd55a/8c402548-efc7-42f1-a218-24c513f9a6b5_2036462354.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "COMTE DE BLIGNAC",
    "wine_name": "Comte De Blignac Bordeaux Sauvignon Blanc 750Ml",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "306952637",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9e3b0afa-29b6-4d78-9310-188e733abd7c/snapshotimagehandler_66435540.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690358",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CHEMIN DES PAPES",
    "wine_name": "Chemin Des Papes Cotes Du Rhone Red 75Cl",
    "region": "France",
    "price_eur": 14,
    "tesco_id": "259270576",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1a5684f5-cfc4-4e30-8732-e872cc8031fa/c427920e-cdf5-4948-8e84-7fa4f68c339c_629508478.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690412",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Spritz Pineapple & Passion Fruit 75Cl",
    "region": "California",
    "price_eur": 5.25,
    "tesco_id": "288178170",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f94d3cc7-ff67-41ab-a3ce-6b399da11751/f062a680-c7fa-4882-86bf-8b3911f31c68_472691020.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Pinot Noir 75Cl",
    "region": "Other",
    "price_eur": 10.5,
    "tesco_id": "283909178",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dd3b1d9a-afeb-4ac2-8615-df80a43805ea/15166405-9a7c-4266-b200-d8526aea7481_1148952371.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009371",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "APOTHIC",
    "wine_name": "Apothic Cabernet Sauvignon 75Cl",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "306932673",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2bbc9b74-f031-4984-9557-2656b0e99295/308a084f-2601-4763-a986-f81479460884_801347103.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688053",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Spritz Raspberry & Lime 75Cl",
    "region": "California",
    "price_eur": 5.25,
    "tesco_id": "288181712",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3795f99a-01d8-4c7d-bf7b-5f835c476eac/44af1178-8f1e-40b2-96f6-10a1345344a1_1134848945.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "PACO Y LOLA",
    "wine_name": "Paco & Lola Albarino 75Cl",
    "region": "Spain",
    "price_eur": 17,
    "tesco_id": "300440607",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/37a564ab-fb27-4763-a5b5-0d1ace46ee97/468d5c0d-bbdb-4136-87b7-95b8a2e5788c_455231225.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LATERAL",
    "wine_name": "Lateral Chilean Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 7.5,
    "tesco_id": "309776697",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a22f8dbc-5cba-4668-97d9-ded4ad8c9255/1975bc83-5e03-42e6-8f17-880e47914d46_1923086740.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "PORTA",
    "wine_name": "Porta 6 Lisboa Rose 750Ml",
    "region": "Rose",
    "price_eur": 13,
    "tesco_id": "314316734",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4555cce1-7b71-4a24-990d-ab9265068f49/0a7dc20a-81c0-4fe4-a2a2-eed0cd15d889_1043166754.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690356",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Finest Prosecco Valdobbiadene Docg 75Cl",
    "region": "Prosecco Sparkling",
    "price_eur": 18,
    "tesco_id": "292561021",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6e2d048f-2358-41c6-b434-667dc4724386/d37f70b2-fb6f-4345-83cf-707066a6b679_1361574104.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959308",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€16.00/75cl",
        "offerText": "€16.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CHÂTEAU CAZEAU",
    "wine_name": "Château Cazeau Bordeaux",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "317310753",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c18cb4ef-3035-4b88-b026-e24b2e4cfa1e/4cb0e830-7fe0-4417-a95d-3e2b20fc7c86_1765359595.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690483",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LOUIS DELAUNAY",
    "wine_name": "Louis Delaunay Brut Champagne",
    "region": "Champagne",
    "price_eur": 40,
    "tesco_id": "277967554",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/04598969-5650-4081-9cbb-bd76996ce2f6/78bf1375-3304-4ea6-9644-60a981e87c30_74610249.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92315800",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€35.00/75cl",
        "offerText": "€35.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 40
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CROFT",
    "wine_name": "Croft Original Pale Cream Sherry 75Cl",
    "region": "Other",
    "price_eur": 17,
    "tesco_id": "257603325",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/405ba988-48d9-475c-ac1e-dc1f40f21fd5/b4dffbfe-289f-4d68-ba92-a9ac3eeff991_488473394.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DOMAINE ARNAUD",
    "wine_name": "Domaines Arnaud Cabernet Sauvignon Reserve 750Ml",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "295640390",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2e296031-f695-4299-aa21-9a5174b8ae6d/snapshotimagehandler_1291766257.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687768",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TALLERO",
    "wine_name": "Tallero Frizzante Spago 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 12.5,
    "tesco_id": "302142393",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6f174526-72e8-49cf-b5b4-65018b5b33ed/snapshotimagehandler_2010793085.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688056",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CATENA",
    "wine_name": "Dv Catena Tinto Historico Malbec 750Ml",
    "region": "Argentina",
    "price_eur": 18,
    "tesco_id": "306827372",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ccf2755d-5403-4609-aed0-90e11c380131/3b46c703-b941-439b-a6f4-5a254c0f066f_1806622541.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961753",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€15.00/75cl",
        "offerText": "€15.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Vin de Bordeaux",
    "wine_name": "Ch Rousseau Bordeaux Rouge 75Cl",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "287063439",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/29198ceb-64c6-4856-aa03-a2a644eced9e/snapshotimagehandler_1403186651.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690409",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Soave Superiore Classico",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "268741000",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dfe4194a-baa1-499f-a953-81551920f07b/caa25ac3-7155-4f72-8a08-c20bdd5a3b33_2033058006.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687753",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VISTA CASTELLI",
    "wine_name": "Vista Castelli Trebbiano D'abruzzo 75Cl",
    "region": "Italy",
    "price_eur": 7.5,
    "tesco_id": "310101015",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/39d51658-371b-4be1-9c4a-9f9511269c5d/98847e4c-c53c-41e9-8a58-bcc89c5a696f_1914917549.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LA BRUNAUDE",
    "wine_name": "LA BRUNAUDE MERLOT 750ml",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "317751098",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs-mktg/b0b04216-fa73-466d-a9d7-c9fcfa1ce9b3/no-image.jpeg",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690376",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA BURGONDIE",
    "wine_name": "La Burgondie Beaujolais Villages 75Cl",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "306652785",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fdeef8d9-869c-402b-82af-0ef9a7308453/snapshotimagehandler_1977076528.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688554",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-05T23:00:00Z",
        "unitSellingInfo": "€13.50/75cl",
        "offerText": "€13.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BLACK TOWER",
    "wine_name": "B By Black Tower Rose 75Cl",
    "region": "Rose",
    "price_eur": 5,
    "tesco_id": "309482733",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7fa62078-9234-436b-b7db-7134fc290221/e280b441-9691-4f74-8fa4-3d6898b6cf64_318751387.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "COMTE DE BLIGNAC",
    "wine_name": "Comte De Blignac Bordeaux Merlot 750Ml",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "306655776",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/de964488-49da-497a-8d54-3d874cf8417c/snapshotimagehandler_194750716.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690475",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Sauvignon Blanc 375Ml",
    "region": "Small Bottles",
    "price_eur": 6.5,
    "tesco_id": "262674463",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e8fd477b-0755-4665-b9da-92b50d25792c/snapshotimagehandler_132346189.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Fino Sherry 37.5Cl",
    "region": "Other",
    "price_eur": 7.5,
    "tesco_id": "299817671",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6a6843a9-4396-411a-aece-c20f2d86e9ef/dfcc25e7-49fb-4c78-ba47-6467d1dafaa7_558008958.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Provence Rose 75Cl",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "292400132",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2a13f6dd-7856-41e7-990e-91618f1e8bad/a52402ff-b033-44c9-a037-5448719c59b2_114512470.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690455",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BAROSSA",
    "wine_name": "Ink by Grant Burge Barossa Ink Shiraz Red Wine",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "295459547",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/28215c45-57ec-498b-a9d8-0b7ae0468e31/f7f7bfca-b1d8-447a-9a03-58eb50dfb6a7_916526469.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690434",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAPE KYALA",
    "wine_name": "Cape Kyala Chenin Blanc 75Cl",
    "region": "South Africa",
    "price_eur": 7.4,
    "tesco_id": "310131100",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/db4400ce-ce4c-42d8-9003-d209f4c6e56a/cc56380c-107e-4020-a1da-d7df3e315e2b_1913781111.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DIABLO",
    "wine_name": "Diablo Black Cabernet Sauvignon 750Ml",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "305919927",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f7d48033-49ee-4c5c-b73d-547d6f5d4a9b/9819a023-5d66-4b3e-a85e-5cf72f8b942e_990501010.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688511",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FREIXENET",
    "wine_name": "Freixenet Italian Rose 75Cl.",
    "region": "Rose",
    "price_eur": 15,
    "tesco_id": "306802729",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2f1c4e39-b4ae-4769-b875-16e187044d26/6e344f31-d11a-4550-b320-d4cb910a380c_748102833.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688154",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PALAIS ST VIGNI",
    "wine_name": "Palais St Vigny Cotes Du Rhone 75Cl",
    "region": "France",
    "price_eur": 8.5,
    "tesco_id": "311805788",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b08e0392-87c6-45ab-a468-f37a79b6a4f2/8ab011b5-fa6f-48c3-b860-0d0449c6ce67_1087516011.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LA BURGONDIE",
    "wine_name": "La Burgondie Macon-Villages Chardonnay 750Ml",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "304137552",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/87590330-9255-431f-a259-0648072e97a2/e41565f3-bec4-480a-a6e9-2fe0c14a12fb_53748187.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961746",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€14.00/75cl",
        "offerText": "€14.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAMPO VIEJO",
    "wine_name": "Campo Viejo Cava Brut 75Cl",
    "region": "Spain",
    "price_eur": 19,
    "tesco_id": "264177023",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/947c3c43-a8b3-4848-853a-258d10722a2f/f27115e2-c745-4a65-9931-e69229f7f20c_1075462888.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688336",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€17.00/75cl",
        "offerText": "€17.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 19
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TRACES",
    "wine_name": "TRACES Sauvignon Blanc",
    "region": "Sauvignon Blanc",
    "price_eur": 15,
    "tesco_id": "316946287",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cdfa0665-afaf-4444-a08d-f376f83d0ace/028b69e1-c9f2-46a4-b036-359c7ebeafaf_1258938044.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690487",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAMPO VIEJO",
    "wine_name": "Campo Viejo Rioja Blanco 750ml",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "292356830",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/acf362ad-c8dd-423e-9b0d-518af44669d7/cc26e342-4247-44d7-9934-67201184c49e_1185173700.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688343",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OYSTER BAY",
    "wine_name": "Oyster Bay Pinot Noir 75Cl",
    "region": "New Zealand",
    "price_eur": 14,
    "tesco_id": "259578506",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4f4bccac-42f6-45fb-a69d-cfafb8e0d5de/4830930e-0220-4ece-96b5-788d59e52058_1572745442.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91962470",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-05T23:00:00Z",
        "unitSellingInfo": "€13.00/75cl",
        "offerText": "€13.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Chablis 75Cl",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "303183780",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/64e4b65d-1016-45b4-955b-f5d321012339/dacbfc50-5740-4310-8a95-da069ccac5c0_1240157575.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687775",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€18.00/75cl",
        "offerText": "€18.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Rioja Crianza",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "316796265",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/52d0b3eb-e796-4f20-867d-331979228f55/9d2fa2a5-3304-4302-b094-f93d3aace5e2_436749640.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690482",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "KUMALA",
    "wine_name": "Kumala Reserve Malbec Red Wine",
    "region": "South Africa",
    "price_eur": 12.5,
    "tesco_id": "283672911",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c9332569-e66a-4df3-bb7d-99d9a1e09182/06c209c7-0f7d-417b-a435-46a1fbeef207_2067034950.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690389",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Ah,",
    "wine_name": "Ah, Cava Brut-Rose 750ml",
    "region": "Spain",
    "price_eur": 25,
    "tesco_id": "321545106",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7a279381-30ff-4b29-9dff-3a54ae6af70b/ce6f99a0-a55b-471f-9d68-1c3e7214c523_1690275453.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91931984",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€20.00/75cl",
        "offerText": "€20.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 25
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TRIVENTO",
    "wine_name": "Trivento Private Reserve Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 14,
    "tesco_id": "296704688",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1bf2e603-42dd-4894-a614-e93eb2877e33/c4571e6e-a3f3-4db0-bfed-ec431e764cdc_1828107279.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690344",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MUD HOUSE",
    "wine_name": "Mud House Sauvignon Blanc France 750Ml",
    "region": "Small Bottles",
    "price_eur": 13,
    "tesco_id": "314111832",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d980f56e-9b71-4571-816e-ea0238993ace/ad5d0caf-6df8-48b3-926e-fce8b09aa959_994623217.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690464",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARTINI",
    "wine_name": "Martini Extra Dry 1L",
    "region": "Other",
    "price_eur": 17.5,
    "tesco_id": "253878996",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9aa6b0dc-0b6d-4666-bf1b-40c40a27360a/8d053a96-d065-43d5-bf7a-1cf0c3034581.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CANTI",
    "wine_name": "Canti Prosecco Spumante 75Cl",
    "region": "Italy",
    "price_eur": 18,
    "tesco_id": "276474413",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6cb99d60-06a6-49d0-9e71-58cefb62e3a7/eb41a717-69e9-4468-8261-b6dbf29d2d9a_750710140.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961745",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€16.00/75cl",
        "offerText": "€16.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Finest Chianti Classico DOCG 75Cl",
    "region": "Italy",
    "price_eur": 12,
    "tesco_id": "296637934",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f1f1207b-e7a5-4867-8e81-d9143e5b0a18/f5fb96e9-3a8e-4f6c-846f-a08ac0f49c21_897207498.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687770",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "APOTHIC",
    "wine_name": "Apothic Merlot 750Ml",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "312848194",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f5196c80-d2b7-493d-a608-02f66873c9aa/59a3efff-5597-4fc1-af7f-fa1b1158165d_1394641373.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688054",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CANTI",
    "wine_name": "Canti Prosecco DOC 3x200ml",
    "region": "Italy",
    "price_eur": 14,
    "tesco_id": "317658687",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/c327445b-d6a2-49b5-a85a-5f21d3248680/8f812ffe-5a07-4f10-9c65-ae3556707323_893546749.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TURNER ROAD",
    "wine_name": "Turner Road Reserve Chardonnay White Wine",
    "region": "California",
    "price_eur": 17,
    "tesco_id": "260572742",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/536e864c-d133-43ca-b81d-03da7dc49456/d2b3a71e-29b3-47af-806d-e40d4ddda3f5_1033474532.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687743",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ALEXIS LICHINE",
    "wine_name": "Alexis Lichine Cremant De Bordeau 750Ml",
    "region": "Prosecco Sparkling",
    "price_eur": 17,
    "tesco_id": "295648807",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6db960fb-4649-40e9-b168-4eed364351d7/50dc9b2f-0190-4e8d-b6ae-79abee7022f2_991014630.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CARMEN",
    "wine_name": "Carmen Insigne Cabernet 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "290694241",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/82ceb865-0da9-4634-9027-dc9470481571/snapshotimagehandler_661773643.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688100",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CASA MANA",
    "wine_name": "Casa Mana Tempranillo 75Cl",
    "region": "Spain",
    "price_eur": 7.4,
    "tesco_id": "310149068",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/61084964-4660-4674-b941-5db0b9d7bccf/923fd32c-287c-4edc-9647-c3b837787ef0_1617757101.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "SHALLOW BAY",
    "wine_name": "Shallow Bay South African Sauvignon Blanc 75Cl",
    "region": "South Africa",
    "price_eur": 10,
    "tesco_id": "309758961",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e88d29af-1ac2-4c9d-9767-98c23220eda7/eb35357d-5a70-4422-a657-a66b7cf35530_1609127471.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690374",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CONO SUR",
    "wine_name": "Cono Sur Organic Cabernet Carmenere 75Cl",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "262253466",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a30e5954-b185-4ece-8576-13fd8f5d1828/2250019b-a2ad-4339-9430-64d8e0f86444_768312199.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688000",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TAPAROO VALLEY",
    "wine_name": "Taparoo Valley Australian Merlot 75Cl",
    "region": "Australia",
    "price_eur": 7.99,
    "tesco_id": "309777892",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/df983faf-c57f-4805-98ed-9ea9891d17b1/4aa840f6-8134-4d12-8901-9efbdd630832_597969582.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MCGUIGAN",
    "wine_name": "Mcguigan Black Label Chardonnay 187Ml",
    "region": "Small Bottles",
    "price_eur": 3,
    "tesco_id": "285313879",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e7851ae1-6e30-43c9-95d2-9276526d67ac/f791ad72-c705-43a9-9b2a-96c3e562fd7f_1383603133.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MARQUES DE RISCA",
    "wine_name": "Marques De Riscal Sauvignon Blanc Rueda 75Cl",
    "region": "Spain",
    "price_eur": 16,
    "tesco_id": "274270317",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/83a14a00-9eac-4260-a4b0-a47beffe2246/snapshotimagehandler_951271065.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688002",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€14.00/75cl",
        "offerText": "€14.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FREIXENET",
    "wine_name": "Freixenet Prosecco Doc 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 25,
    "tesco_id": "296735680",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ab3052d0-2bda-4601-a47d-9bf937930503/10301322-ec5b-4a40-aea6-35d71a80cac6_385366871.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688150",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€22.00/75cl",
        "offerText": "€22.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 25
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUES DE RISCA",
    "wine_name": "Marques De Riscal Reserva 75Cl",
    "region": "Spain",
    "price_eur": 26,
    "tesco_id": "260670234",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f813737e-4739-4f38-a4da-e617feed6589/584acd35-de89-4811-aa88-1baf2903d1ff_1082931385.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91908850",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€22.00/75cl",
        "offerText": "€22.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 26
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "The Wanderer ",
    "wine_name": "The Wanderer Malbec",
    "region": "Argentina",
    "price_eur": 14,
    "tesco_id": "317548898",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/24b0226b-1815-4b49-9a01-c2967f4978aa/71882d73-d98b-4071-aee0-c98d8dbdf7f8_357581408.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687991",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FREIXENET",
    "wine_name": "Freixenet Chianti 75Cl",
    "region": "Italy",
    "price_eur": 15,
    "tesco_id": "306503467",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/73691c01-0f2f-4d00-b87b-285562a6938b/e8e90691-7fbf-474f-9afc-6991acadda58_1661706091.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688165",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MOST WANTED",
    "wine_name": "Most Wanted Sauvignon Blanc Can 187Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 3,
    "tesco_id": "313739068",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f8b89df2-5779-486a-a405-079c05a06ea8/e07aeb8b-cf60-4492-8e9c-e67d2f37ff75.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MOST WANTED",
    "wine_name": "Most Wanted Regions Primitivo 75Cl",
    "region": "Italy",
    "price_eur": 13,
    "tesco_id": "314321693",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b75364c8-efbe-4290-a4fa-59558211576a/0bee7e05-0090-4fec-b04a-f6bf23fcec47_836226080.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690405",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAT ROOSTER",
    "wine_name": "Fat Rooster Cabernet Sauvignon",
    "region": "Portugal",
    "price_eur": 15,
    "tesco_id": "317761063",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5eb3efbd-7e3c-4bb4-97ff-d60dfd8ae0ec/f5dd1a09-7004-42d0-baf1-740034aeee80_536566565.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690425",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MASI",
    "wine_name": "Masi Campo Fiorin 75Cl",
    "region": "Italy",
    "price_eur": 20,
    "tesco_id": "251186717",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0125d75b-8714-4bb9-a340-3f8c75616854/snapshotimagehandler_502527325.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688152",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€18.00/75cl",
        "offerText": "€18.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARTINI",
    "wine_name": "Martini Rosso 1L",
    "region": "Other",
    "price_eur": 17.5,
    "tesco_id": "253879091",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/797de19f-e9ba-4a78-81c5-a8ec36e6d2c5/snapshotimagehandler_448479075.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Santa Rita 120 Cabernet Sauvign 375Ml",
    "region": "Small Bottles",
    "price_eur": 6.5,
    "tesco_id": "262654504",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5d802910-cc9a-4daf-b51f-d2171d6a4298/snapshotimagehandler_522518994.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Special Reserve Port 75Cl",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "251180136",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/dc152b1e-7a44-4b9b-95e5-95400c14b701/b741b0e2-31f9-46ac-9e1a-dff374b7b753_578195996.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "VILLA MARIA",
    "wine_name": "Villa Maria Priv. Bin Pinot Grigio 75Cl",
    "region": "New Zealand",
    "price_eur": 13.5,
    "tesco_id": "263970871",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/792db730-9a12-4bd0-a3a0-8211074a2e8e/6be7a2dc-8ea7-4d99-84d2-ca0ee2556aa0_1238608090.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690393",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CUNE",
    "wine_name": "Cune Rioja Grand Reserva 75Cl",
    "region": "Spain",
    "price_eur": 22,
    "tesco_id": "293674030",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2e71770f-1838-4a39-bf63-48aff92176b7/b4909dc5-291e-4353-9a37-7f3bd298f060_1632532347.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CUNE",
    "wine_name": "Cune Reserva 75Cl",
    "region": "Spain",
    "price_eur": 20,
    "tesco_id": "294015798",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cc6032e5-c5e6-47f9-86ca-6ecae086173d/f8650033-1c87-44c7-9901-de2ede05cfb8_1944636191.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688059",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€15.00/75cl",
        "offerText": "€15.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CHATEAU",
    "wine_name": "Chateau Les Mauberts Bordeaux 75Cl",
    "region": "France",
    "price_eur": 14,
    "tesco_id": "289288429",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/14c3ec2f-2d1a-40c2-b9bb-cb05a9dbe1e2/25ebd305-a742-4915-af62-991489daab49_1000448052.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690391",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Château Grand Puch",
    "wine_name": "Chateau Du Grand Puch Bordeaux Superieur 750Ml",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "314420973",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/96d75b07-3d65-45f9-b564-1d5e61b8b493/054292e3-3516-4a77-9f13-653c0fafffba_1457019280.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690392",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUÉS DE LOS ZANCOS",
    "wine_name": "Marques De Los Zancos Rioja 75Cl",
    "region": "Spain",
    "price_eur": 8,
    "tesco_id": "311216523",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f306d5b6-ee2f-41bc-a973-fa6e0ee05bd9/d1f88fd8-0f23-40cd-b9d5-64e181a55762_1823371157.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards White Grenache 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "255244856",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/edb8e8b0-5ec7-4251-b1b9-7950dcb6afa6/a6648386-132c-43fc-82c8-09ef7b481617_990542639.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CARMEN",
    "wine_name": "Carmen Wave Series Pinot Noir 750 Ml",
    "region": "Chile",
    "price_eur": 15,
    "tesco_id": "281205714",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/865a64cb-0b20-415d-98d2-51f709a4da1e/snapshotimagehandler_747502051.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688102",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARK WEST",
    "wine_name": "Mark West Pinot Noir 750Ml",
    "region": "California",
    "price_eur": 15,
    "tesco_id": "315067076",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5b3fca07-02b3-413b-b1d6-284929e29a4c/1b3cdf77-788a-49a5-a372-c289ef015a5a_1721310609.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688055",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino I Gran Reserva Rioja",
    "region": "Spain",
    "price_eur": 25.5,
    "tesco_id": "254181286",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/df7aaedc-26fc-4bfb-8422-067aa2652698/3d314de8-2f1f-4ae2-9442-e2105735969c_1110581891.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "PICCINI",
    "wine_name": "Piccini Collezione Privata Toscana IGT 750ml",
    "region": "Italy",
    "price_eur": 15,
    "tesco_id": "317638967",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b85eb972-1322-4e0f-ae5e-e4f4ce4363a2/5a3b3ff2-5e6a-4380-8f2e-c30b1cd3d890_758628455.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688491",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards Summer Rose 75 Cl",
    "region": "California",
    "price_eur": 5.25,
    "tesco_id": "283222955",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bf333c54-58b2-49d6-ad96-3cbc546bcee8/c4f56c8a-83f4-4a90-b92a-661b81e5f334_1191805009.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LUIS FELIPE EDWARDS",
    "wine_name": "Luis Felipe Edwards Malbec 75Cl",
    "region": "Chile",
    "price_eur": 15,
    "tesco_id": "310696067",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/be098dcb-5ce8-4af8-8cbb-4b5a4297466a/f678e736-ffaa-4491-9b9c-d414af317736_1679590215.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690365",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Black Tower",
    "wine_name": "B Secco Rose 75Cl",
    "region": "Low Alcohol",
    "price_eur": 5,
    "tesco_id": "290538295",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/15fa1780-3973-4aa8-9d5e-6019b81c1da4/snapshotimagehandler_41863038.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "MUMM",
    "wine_name": "G.H. Mumm Champagne Brut Cordon Rouge",
    "region": "Champagne",
    "price_eur": 52,
    "tesco_id": "257377027",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/813ea30f-590f-442f-aad2-3a4b86ac0dea/3b8c5395-ea18-40dd-975d-b0dbd359dc1e_2008184687.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards Cabernet Sauvignon 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "257223204",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f24f7784-d6b0-46b8-8d9b-07bb028e7fcd/546a3a8b-2b69-4343-8a0d-08be6c3b3231_456156748.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BLOSSOM HILL",
    "wine_name": "Blossom Hill Red 75Cl",
    "region": "California",
    "price_eur": 10,
    "tesco_id": "259712890",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ec0d7eca-8756-4591-86c5-890fe602bfd3/3db83920-cba8-46e5-b799-9ed66f1e6e55_553804968.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Vermouth Bianco 1Ltr",
    "region": "Other",
    "price_eur": 12,
    "tesco_id": "253785685",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/29b109be-9534-4de3-b7df-7fb7ce0f6c79/6275f1b3-daae-4cea-aabf-af1161fd269d.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DIABLO",
    "wine_name": "Diablo Sauvignon Blanc 75Cl",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "312110744",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a5d16d7b-7722-43d1-a287-0129570f64bb/9624e43c-6bdf-4674-b2c1-f16f149c42d1_1970385473.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688514",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GARY BARLOW",
    "wine_name": "Gary Barlow Western Cape Pinot Grigio 750ML",
    "region": "South Africa",
    "price_eur": 12,
    "tesco_id": "317653928",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4a13165d-3a8f-4f45-b671-766cd77adcfb/8798565a-b6b8-4e5c-a284-d22c2c552bc7_522820783.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688033",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Valle De Leyda Chardonnay 75Cl",
    "region": "Chile",
    "price_eur": 12,
    "tesco_id": "306827032",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cc28ef64-a110-40ad-b2a1-fb0703bd2849/64543678-98db-4fec-b422-82f530a5d449_733999540.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687780",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "OYSTER BAY",
    "wine_name": "Oyster Bay Merlot 75Cl",
    "region": "New Zealand",
    "price_eur": 13.5,
    "tesco_id": "261618256",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/be887bc7-266f-4667-95cf-3334381958b2/dd63900f-50d5-4347-b357-d0fc7df42628_151046356.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91924460",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Rivero Ulecia Tempra- Nillo Rioja 75Cl",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "300734623",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2bdc1a12-76e2-4069-8985-07c336f71b23/snapshotimagehandler_721333848.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690488",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Ca de Lago",
    "wine_name": "Ca De Lago Inzolia 75Cl",
    "region": "Italy",
    "price_eur": 7.5,
    "tesco_id": "271165793",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7eefdaea-952d-47bb-83fd-9af156fad252/9c7a3f06-b2f5-48a1-8d9a-3b6a7490db74_1079519284.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "GERARD BERTRAND",
    "wine_name": "Gerard Bertrand Cote Des Roses 75Cl",
    "region": "Rose",
    "price_eur": 18,
    "tesco_id": "312363784",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/75d4fa1a-3037-4a2b-909b-bdfa4c47a0d4/c441a629-df61-472a-a349-b82535d293df_1738344704.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961744",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€14.00/75cl",
        "offerText": "€14.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "JP CHENET",
    "wine_name": "JP. Chenet Merlot",
    "region": "France",
    "price_eur": 10,
    "tesco_id": "257439387",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f5351dcd-2baa-4aeb-b1f6-d048cedcb001/a0c1139e-a123-4938-a3ba-aa8edf53cfa8_1456730496.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690378",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TRIVENTO",
    "wine_name": "Trivento Argentina White Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 11,
    "tesco_id": "304392778",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/45a5fc6a-4d0a-474e-9aec-8fc06ab83da9/a1fb58f9-0e85-4ba8-95cc-5ef4663a9acc_636845047.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688391",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-04-27T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 11
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Rivero Albario Rias Baixas 75Cl",
    "region": "Spain",
    "price_eur": 16,
    "tesco_id": "300826906",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4941e8ce-bfc4-4b21-8e67-5751c7f2a809/abcc1842-cbac-4222-a635-f4310c439233_715542223.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "IRON MAIDEN",
    "wine_name": "Iron Maiden Darkest Red",
    "region": "Portugal",
    "price_eur": 15,
    "tesco_id": "317760438",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4fdd993c-e80e-4fe6-b6d2-72d76310bac9/b6a275af-20e4-4c09-b9f5-c5010304d98f_5493091.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690357",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita Early Harvest 120Sauvg Blanc 75Cl",
    "region": "Chile",
    "price_eur": 10,
    "tesco_id": "300422670",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9045e7cc-0165-4e05-8b74-9ac12038b25d/5a0ca7bf-b212-47ef-8462-42cd2d5002a6_1849291175.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688087",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WOLF BLASS",
    "wine_name": "Wolf Blass Yellow Label Cabernet Sauvignon 75Cl",
    "region": "Australia",
    "price_eur": 14,
    "tesco_id": "259713860",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9c8cafcd-d33a-4de2-9572-7072b390b9aa/f56d5b9f-2a90-46f8-aa9e-6476793f7b5a_2117956268.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687995",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WOLF BLASS",
    "wine_name": "Wolf Blass Red Label Chardonnay Semillon 75Cl",
    "region": "Chardonnay",
    "price_eur": 13.5,
    "tesco_id": "253902778",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/506b59c1-2ef6-4c94-9c83-9683494a1c5e/a93d0855-5733-48ef-a049-5021fa4b00ca_195072243.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688163",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Montagne St Emilion 75Cl",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "271773804",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/61dbd701-b80a-46c7-803e-b061026a2b21/dc95d176-d6f7-471a-87e1-f768174e4740_1107009782.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690373",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Cabernet Sauvignon 75Cl",
    "region": "Other",
    "price_eur": 10.5,
    "tesco_id": "301744379",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4af97351-0112-40bb-998c-acf871684abe/a765e8ab-c504-41ec-a130-f6c5dd3fd990_900503221.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009372",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CANTI",
    "wine_name": "Canti Prosecco Rose 75Cl",
    "region": "Italy",
    "price_eur": 20,
    "tesco_id": "308479296",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/fd42fe69-c8c2-4b25-ae55-1564e808184e/87bc59d2-6f0b-4cbf-a336-19fd3dd1efda_1349154131.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961748",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€16.00/75cl",
        "offerText": "€16.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PENFOLDS",
    "wine_name": "Penfolds Koonunga Hill Shiraz Cabernet 75Cl",
    "region": "Australia",
    "price_eur": 16,
    "tesco_id": "257173026",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/58cad02d-2055-4c66-9ae8-31e87b18386e/1a18e028-53d1-4f3e-8442-35d29fae362a_842425983.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91959272",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 16
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ALTA VEDUTA",
    "wine_name": "Alta Veduta Chianti 75Cl",
    "region": "Italy",
    "price_eur": 8.5,
    "tesco_id": "311794131",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/eee67426-0fba-4ed8-b0b8-cb43523d8447/b9afbef0-799b-4229-9165-2b008496552f_975709064.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "FAUSTINO",
    "wine_name": "Faustino Rivero Ulecia Crianza Rioja 75Cl",
    "region": "Spain",
    "price_eur": 12,
    "tesco_id": "300734829",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d9070739-c3ee-4dfa-9ca4-c5618d36fd4c/snapshotimagehandler_754185549.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690431",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TRACES",
    "wine_name": "TRACES Grenache Rose",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "316657684",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/386b6db7-70df-4070-b8d6-f17a41357b69/4b799a9d-ba99-4275-93ec-35df8caf7e15_960184287.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690347",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Saint Chinian 75Cl",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "283868185",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9c2a5f7f-0931-43ba-849b-eb5e2d289e90/fb836418-dfaa-43b0-ad66-3747b994bdfa_339588413.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687763",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GRAND VIN",
    "wine_name": "Grand Vin De Stellenbosch Sauvignon Blanc 75Cl",
    "region": "South Africa",
    "price_eur": 12,
    "tesco_id": "301884846",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/73a89e90-0854-4aba-acb9-53e42639ea52/fb75708e-0960-49f0-9ec3-3a6a06d524e2_1196194770.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690478",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Signargues Cotes du Rhone Villages",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "306665879",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b3df55e0-7787-4554-93cf-c92e9b80f458/3f345937-4fb7-4f78-b7c4-9544d6dab44e_960571145.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687778",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Shiraz 75Cl",
    "region": "Spain",
    "price_eur": 10.5,
    "tesco_id": "309495136",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/08d0a069-7162-4d57-b1de-bca849021bfc/a6340c2b-215a-4cd3-aef2-b56a6ba6eb62_1233612157.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009373",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TAPAROO VALLEY",
    "wine_name": "Taparoo Valley Australian Shiraz 75Cl",
    "region": "Australia",
    "price_eur": 7.99,
    "tesco_id": "309776927",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f4f629e1-169c-46fd-9cdd-ac0fe0649e30/4bd849a2-ea07-4b5a-b5f4-ea4558324756_79153365.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Ribera Del Duero 75Cl",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "306943389",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d314feeb-25c8-4ef5-8324-83e46a0acbe8/6d168d5b-571f-4a9f-957f-9ea8cb36590e_454528984.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687784",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Merlot 75Cl",
    "region": "Other",
    "price_eur": 10.5,
    "tesco_id": "308870811",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a167e771-1e31-41ef-9846-20bee74bb22a/626b150e-c3cc-4110-819b-95da5e6a044f_1207270810.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92009367",
        "promotionType": None,
        "startDate": "2025-04-21T23:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.00/75cl",
        "offerText": "€8.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARQUES",
    "wine_name": "Marques De Caceres Cava Brut 750Ml",
    "region": "Cava",
    "price_eur": 20,
    "tesco_id": "314433612",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ff35446f-dab7-4cdd-ac1e-b5b7f33e478a/3e0d5ff1-9096-42a3-90dd-62b71eaebae2_466795565.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688057",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€18.00/75cl",
        "offerText": "€18.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "VILLA MARIA",
    "wine_name": "Villa Maria Blush Sauvignon 750ml",
    "region": "Rose",
    "price_eur": 13.5,
    "tesco_id": "308468038",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e7625105-fc61-45f3-b282-794a76cfdd1e/e10bea8c-2bb6-453d-86ed-5674ca497686_1051351942.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688416",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "WAIRAU COVE",
    "wine_name": "Wairau Cove Merlot 75Cl",
    "region": "New Zealand",
    "price_eur": 13,
    "tesco_id": "299639985",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d2d5a259-7623-4a4b-9081-b860ba85bd4d/5443f4b8-9380-45de-afaa-8b9447f3d1d3_1091406659.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687774",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Western Australia Chardonnay",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "306822262",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b2cd3940-7a43-4c1e-a271-ccfbac1df710/255be06c-7e59-452e-a067-c9aab061123e_1062531975.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690386",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Extra Dry Vermouth 1Ltr",
    "region": "Other",
    "price_eur": 12,
    "tesco_id": "253778043",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ca9c33d8-4fae-4e52-932e-a804f68e0e35/5d668e4d-561c-45a4-8660-59b1e3f50b56.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CELLIER DES CLES",
    "wine_name": "Cellier Princes Aoc Cotes Du Rhone Red 750Ml",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "293993176",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2e08ce69-d368-40c4-ae7e-1047291e3c1d/snapshotimagehandler_1218263172.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690345",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAVE DES ROCHES",
    "wine_name": "Cave Des Roches Cotes De Gascogne 75Cl",
    "region": "France",
    "price_eur": 8.5,
    "tesco_id": "311433012",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f16dd610-89dc-4685-af41-14563a550906/3a476199-5c3c-4eb4-bfff-d26bc4b39037_491720198.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DARK HORSE",
    "wine_name": "Dark Horse Sauvignon Blanc 75Cl",
    "region": "North America",
    "price_eur": 12.5,
    "tesco_id": "295163384",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/3eeb0107-b94d-47e7-87bf-453677581a37/efe6d8d7-5e96-4278-9d45-024221221cf6_776810703.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688052",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "BEEFSTEAK CLUB",
    "wine_name": "Beefsteak Club The Beast Dark Red 750Ml",
    "region": "Portugal",
    "price_eur": 15,
    "tesco_id": "312828477",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f10ce723-6359-431e-991c-9ace28cf67dd/9430ab7d-fee9-4c3c-a07c-3e6d0b9f2474_1145307479.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690421",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TORRES",
    "wine_name": "Torres Sangre De Toro 0% White 750Ml",
    "region": "Spain",
    "price_eur": 8,
    "tesco_id": "304032278",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/1dde26c7-f856-4240-8534-3ecbfffd3ea3/1c840674-8285-4776-bfad-80d1309edd0c_1984179268.jpeg?h=225&w=225",
    "size": "litre",
    "promotions": []
  },
  {
    "producer_brand": "LA BURGONDIE",
    "wine_name": "La Burgondie St Bris Sauvignon Blanc 750Ml",
    "region": "France",
    "price_eur": 20,
    "tesco_id": "307159969",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/29b32795-7b0e-4f85-905f-1fc0672ea60a/snapshotimagehandler_1443292944.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91961750",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€15.00/75cl",
        "offerText": "€15.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 20
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Premier Cru Non Vintage Champagne 37.5Cl",
    "region": "Champagne",
    "price_eur": 20,
    "tesco_id": "255245423",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/9f84f66d-a6ce-4fab-8f46-05bf1d8f6c54/6a0bd689-908b-49c5-b4c0-b6024b08666d_1535166591.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest South African Shiraz 75Cl",
    "region": "South Africa",
    "price_eur": 12,
    "tesco_id": "274763570",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b6d08312-ea30-4f4a-b44d-d85cdb2d4ce8/15b79199-6c26-4730-9bca-a58b60f173c0_547323173.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690406",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CARMEN",
    "wine_name": "Carmen Wave Left Wave Sauvignon Blanc 750Ml",
    "region": "Sauvignon Blanc",
    "price_eur": 15,
    "tesco_id": "281205372",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/794d3d76-efdd-4d28-9621-beb86a19f816/snapshotimagehandler_2024996559.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688097",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GONZALEZ",
    "wine_name": "Gonzalez Byass Tio Pepe Fino Sherry 750ml",
    "region": "Other",
    "price_eur": 16.5,
    "tesco_id": "257467791",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8e7758a4-2dd5-4e97-ba2d-8239a42d3021/d0e0155e-b90e-4f5d-ad79-ddecce97dd46_182704452.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "BUCKFAST",
    "wine_name": "Buckfast 750Ml",
    "region": "Other",
    "price_eur": 16,
    "tesco_id": "301155609",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/f9031f98-f616-45ee-8d93-f8577d26e71c/fc99650d-c483-4b05-aa19-554096ed1ffe_172082213.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LAURENT MIQUEL",
    "wine_name": "Domaine Saint Blaise -Organic Rose South Of France",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "315143049",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/aaa8170b-e744-4f33-b3cb-0a60a5157fbf/7aa2de8c-5a8c-4dd3-9bdd-de5dd3dd4c6a_2081011065.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690462",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Cotes du Rhone Villages Blanc",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "315740483",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/981615c9-551e-4c1d-8866-4ea73e074f63/d84fd15d-c261-4b6e-8e5b-71c138c502cf_90492475.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690480",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Vina Del Cura Rioja Gran Reserva 75",
    "region": "Spain",
    "price_eur": 19,
    "tesco_id": "256150055",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bee25be7-6e14-4c91-af51-187560a4fbdb/c8e2afd9-e7f1-4330-a24b-a190d6a129e9_1737474434.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Vermouth Rosso 1Ltr",
    "region": "Other",
    "price_eur": 12,
    "tesco_id": "253786465",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2d2e14c0-b919-4e31-b928-a5803e574a65/f1ee41a3-c3fa-4d25-a6fd-b3ff85bb3641.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "I Heart Prosecco 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 21,
    "tesco_id": "294957011",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5f1880c0-e87f-4baa-abea-f0f3bce8bca4/c4fda60c-7f44-49d7-af28-8f1ab84cd6a1_519006048.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690472",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€18.00/75cl",
        "offerText": "€18.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 21
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TRACES",
    "wine_name": "TRACES Cinsault",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "316948835",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/37bf7d9e-c516-4283-a8b5-37f1b20f758f/68bc31d1-ef3a-4505-9f04-fdfcc991f848_459909922.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690350",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ART OF WINE",
    "wine_name": "The Great Wave Sauvignon Blanc",
    "region": "Chile",
    "price_eur": 12,
    "tesco_id": "317760381",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/06b86fba-c4a5-4ebe-9b83-28bb55424e01/93519b0f-171f-4854-a49e-dd83964b6629_1581904978.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690403",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "Marques de Colbert Reserva",
    "wine_name": "Marques de Colbert Reserva",
    "region": "Spain",
    "price_eur": 17,
    "tesco_id": "317653709",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d6e41c15-c288-4cf0-afb6-c89c5ae1a549/acae9a71-9139-4803-961a-d6e6a7c0fe32_1308249213.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91924885",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 17
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO",
    "wine_name": "Tesco Tawny Port 75Cl",
    "region": "Other",
    "price_eur": 15,
    "tesco_id": "255247191",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/e50b788c-5420-4b27-a637-42d660776e5b/eaa16f42-ff3a-4afa-9ad0-e0ebcbca6f9d_457176570.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest South African Pinotage 75Cl",
    "region": "South Africa",
    "price_eur": 12,
    "tesco_id": "274670437",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2e0ad2a2-adff-44c6-9df6-79601d97c91c/1a8cf111-3561-4f01-abd5-61317eb74e5a_69142937.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687757",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.50/75cl",
        "offerText": "€9.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "I HEART",
    "wine_name": "Mionetto Organic Prosecco 75Cl",
    "region": "Sparkling Wine",
    "price_eur": 18,
    "tesco_id": "301839969",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6f3a2d9c-31d0-481d-bf1e-dc2e252df593/161e2435-a72a-4c20-811f-b441ffd5d5ff_1844543139.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "FREIXENET",
    "wine_name": "Freixenent Sauvignon Blanc 750Ml",
    "region": "Spain",
    "price_eur": 15,
    "tesco_id": "309483444",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/12ca405e-aa4c-46b1-8960-aa98d7897d24/b656b1ba-f145-4809-874c-902cd97df9bc_996198949.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688153",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Cahors Malbec 75Cl",
    "region": "France",
    "price_eur": 12,
    "tesco_id": "257169239",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/646bfe91-748b-44f4-80c6-00ba5438cf33/e9afd26b-6c53-4b2f-a718-9f9817b9d539_1857222266.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CATENA",
    "wine_name": "Catena Malbec 75Cl",
    "region": "Argentina",
    "price_eur": 21,
    "tesco_id": "300440642",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/99b4a938-bfee-417c-8e87-21041d748485/adce49ac-40b3-4327-a46b-2777220578ad_372108597.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "DOMAINE ARNAUD",
    "wine_name": "DOMAINE ARNAUD GRANDE RESERVE CHARDONNAY",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "317739730",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs-mktg/b0b04216-fa73-466d-a9d7-c9fcfa1ce9b3/no-image.jpeg",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687863",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "POR DO SOL",
    "wine_name": "Por Do Sol. Vinho Verde 75Cl",
    "region": "Other",
    "price_eur": 8.5,
    "tesco_id": "311445326",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/a47402d9-23bb-463b-895f-01006a4432d6/876ca482-2a0e-42f2-b21b-26e1807e18fb_300170118.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Douro 75Cl",
    "region": "Portugal",
    "price_eur": 15,
    "tesco_id": "305952587",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8aa1049d-40e7-47bd-9372-cde0f8806b8c/b12d1f05-5724-4c8c-954e-a0d0fbd56af1_84054665.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687779",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "SHALLOW BAY",
    "wine_name": "Shallow Bay Cabernet Sauvignon",
    "region": "South Africa",
    "price_eur": 10,
    "tesco_id": "315071773",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b607f8ee-d03d-4f15-a854-127e9f7f34e4/ebef737a-fc52-465a-b5f8-61023ccf8649_309223994.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "92006136",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€8.50/75cl",
        "offerText": "€8.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 10
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAPE KYALA",
    "wine_name": "Cape Kyala Sauvignon Blanc 75Cl",
    "region": "South Africa",
    "price_eur": 7.5,
    "tesco_id": "310689511",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/cc0c0557-09a9-49bd-af9e-8d15f7b490b8/d486c09d-8e11-468b-9f9e-9e2e4a5919a9_101845249.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "CASILLERO",
    "wine_name": "Casillero Reserva Especial Cabernet Sauvignon 75Cl",
    "region": "Chile",
    "price_eur": 14,
    "tesco_id": "299804041",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4268d6b7-42c2-4454-accd-cdd33a76bcb5/c3741b99-ddb4-43cc-ae84-38704d11e5da_1220497216.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688350",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Premier Cru Rose Champagne 75Cl",
    "region": "France",
    "price_eur": 40,
    "tesco_id": "274763190",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/7eea47a4-0c22-403f-8334-44a4029e912f/6d52fb89-d43d-4636-9003-da00623f642f_440312085.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "LES TUGUETS",
    "wine_name": "Les Tuguets Madiran 75Cl",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "262260359",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/2c5038c1-dc6c-4ab9-8dde-4bb02f2e4f9b/c3efb872-35cb-4504-b888-7dd32d3cac0d_1512211263.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690397",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Save 1/3 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "PLAIMONT",
    "wine_name": "Plaimont Saint Mont Grande Cuvee 75Cl",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "314937310",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/b719981c-05c7-4d50-a350-e916353f31fe/e46ee23a-7caa-4895-a988-6b2a85a94b0b_513250840.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690454",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€11.00/75cl",
        "offerText": "€11.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "ATMOSPHERE",
    "wine_name": "Atmosphere Touraine Sauvignon Blanc 750Ml",
    "region": "France",
    "price_eur": 14,
    "tesco_id": "309742271",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/6b720c5d-9a63-444e-a859-44183208a291/6eb9f8d0-16fc-41b4-b3f9-e966ba066419_1891905216.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687792",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 14
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "FRENCH CONNECTION",
    "wine_name": "French Connection Aoc Languedoc 750 Ml",
    "region": "France",
    "price_eur": 18,
    "tesco_id": "266879595",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/600382b9-7cd0-43a6-92b5-add856a92674/e889ed12-a560-418d-990c-98fa5db4fc66_646229032.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91907083",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Half Price Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 18
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "CAVE DES ROCHES",
    "wine_name": "Cave Des Roches Malbec 75Cl",
    "region": "France",
    "price_eur": 8.5,
    "tesco_id": "311443000",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/ad4646f9-a289-4508-bf36-006219ffb238/2b9b61f2-323b-4f74-b53f-b58e5da70095_659758961.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Premier Cru Brut Champagne 75Cl",
    "region": "Champagne",
    "price_eur": 40,
    "tesco_id": "255245446",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/d6c14f41-3339-46fe-b7b7-5727b941565c/512d4c27-8184-4620-8cac-14ba34393ae9_188596285.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Western Australian Sauvignon Semillon 75Cl",
    "region": "Australia",
    "price_eur": 12,
    "tesco_id": "306825921",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/466b4739-c336-4db4-9ebd-a76dfe97c34f/419b1b4f-88fd-4da7-a9ff-e48de4cd6c69_898861451.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690349",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.50/75cl",
        "offerText": "€10.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "LA BURGONDIE",
    "wine_name": "La Burgondie Chardonnay 75Cl",
    "region": "France",
    "price_eur": 15,
    "tesco_id": "296843592",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/4f382fa3-3a20-4564-b4eb-69621972c23a/a6b7116b-6b81-4747-9502-064795b5626b_504258336.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688553",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-05T23:00:00Z",
        "unitSellingInfo": "€13.50/75cl",
        "offerText": "€13.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest Wrattonbully Cabernet Sauvignon",
    "region": "Australia",
    "price_eur": 15,
    "tesco_id": "314945219",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/51517b3a-2906-4d38-9572-0a2947270bec/ab0e1067-38cf-4c1d-a62b-497803c36f2e_419070469.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687818",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.50/75cl",
        "offerText": "€12.50 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 15
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GALLO",
    "wine_name": "Gallo Family Vineyards Chardonnay 75Cl",
    "region": "North America",
    "price_eur": 10,
    "tesco_id": "256651136",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/21e36030-a4fd-4944-9edb-da6b0023ab64/9e5c17f2-c6bc-4d81-a4c7-a245840742e2_2099085478.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "SANTA RITA",
    "wine_name": "Santa Rita 120 Coastal Sauvignon Blanc 750ml",
    "region": "Chile",
    "price_eur": 12,
    "tesco_id": "317737041",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/bc0bebae-eecd-4c06-b8c3-fb23caaee4d3/db765396-d92b-4d01-be0c-c75369b160f1_625554246.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91688085",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€9.00/75cl",
        "offerText": "€9.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "TORRES",
    "wine_name": "Torres San Valentin White 75Cl",
    "region": "Other",
    "price_eur": 13.5,
    "tesco_id": "282392247",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/da36e5dc-aad6-444b-9660-394fbd1e5e14/snapshotimagehandler_1759490016.jpeg?h=225&w=225",
    "size": "litre",
    "promotions": [
      {
        "promotionId": "91688161",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€13.33/litre",
        "offerText": "€10.00 Save 25% Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MARTINI",
    "wine_name": "Martini Bianco 1L",
    "region": "Other",
    "price_eur": 17.5,
    "tesco_id": "251613265",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/db0f29cb-7045-4ef3-98d5-3dfd9ca9ed74/e8c33ab5-04c6-445c-b193-6bc665d368cc.jpeg?h=225&w=225",
    "size": "litre",
    "promotions": []
  },
  {
    "producer_brand": "MARTINI",
    "wine_name": "Martini Bianco Vermouth 750ml",
    "region": "Other",
    "price_eur": 13.5,
    "tesco_id": "255506305",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/8247d38b-7554-4d0a-8f79-4f52f43fa897/1083240d-34e4-4a7b-aa65-e9f19f1d7f49_1204060635.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "TESCO finest",
    "wine_name": "Tesco Finest 10 Year Old Tawny Port 75Cl",
    "region": "Other",
    "price_eur": 20,
    "tesco_id": "255247179",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/0dd8fb78-5750-42f0-a3a1-c4a374765cc5/3c97bdaf-1552-481d-8a4d-81b54ce97ed5_588191229.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": []
  },
  {
    "producer_brand": "SIX POETS",
    "wine_name": "Six Poets Chardonnay",
    "region": "North America",
    "price_eur": 12,
    "tesco_id": "316542883",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/278425b6-7f3b-4685-a056-7069c79f8af4/836cced9-f4aa-4de1-9a69-151caed9eedf_2131158280.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690367",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€10.00/75cl",
        "offerText": "€10.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 12
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "GRATIEN & MEYER",
    "wine_name": "Champagne Albert Meyer Cuvee Brut Non Vintage 750Ml",
    "region": "Champagne",
    "price_eur": 40,
    "tesco_id": "315398162",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/5039885c-1ca1-4fe6-ae73-2cc2b331bd7b/99b105d0-1476-4786-bcdc-586159333625_2136204113.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91687832",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€35.00/75cl",
        "offerText": "€35.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 40
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  },
  {
    "producer_brand": "MOST WANTED",
    "wine_name": "Most Wanted Sauvignon Blanc 75Cl",
    "region": "New Zealand",
    "price_eur": 13.5,
    "tesco_id": "296704187",
    "image_url": "https://digitalcontent.api.tesco.com/v2/media/ghs/18e93ca8-c178-4301-8992-e3fb58aefff2/3cd5dc26-6976-49b8-b87f-d936329638ad_687809583.jpeg?h=225&w=225",
    "size": "75cl",
    "promotions": [
      {
        "promotionId": "91690444",
        "promotionType": None,
        "startDate": "2025-03-19T00:00:00Z",
        "endDate": "2025-05-06T23:00:00Z",
        "unitSellingInfo": "€12.00/75cl",
        "offerText": "€12.00 Clubcard Price",
        "price": {
          "beforeDiscount": None,
          "afterDiscount": 13.5
        },
        "attributes": [
          "CLUBCARD_PRICING"
        ]
      }
    ]
  }
]

# --- Process the list to remove specified fields ---
cleaned_wine_list = []
fields_to_remove = {"tesco_id", "promotions"} # Use a set for efficient lookup

for wine_entry in final_wine_list:
    # Create a new dictionary containing only the keys NOT in fields_to_remove
    cleaned_entry = {
        key: value for key, value in wine_entry.items()
        if key not in fields_to_remove
    }
    # Add fields that might be missing but needed for RAG later (optional, set to None)
    cleaned_entry.setdefault('type_grape', None)
    cleaned_entry.setdefault('abv_percent', None)
    cleaned_entry.setdefault('bottler_importer', None)
    cleaned_entry.setdefault('tasting_notes', None) # Add placeholders for RAG/API enrichment

    cleaned_wine_list.append(cleaned_entry)

# --- Output the cleaned list ---

print("\n--- Cleaned Wine List (Removed 'tesco_id' and 'promotions', added placeholders) ---")
# Print the first 5 cleaned items for verification
print(json.dumps(cleaned_wine_list[:5], indent=2))

# Optional: Save the cleaned list to a new JSON file or .jsonl file for RAG
output_filename_json = "tesco_wines_cleaned.json"
output_filename_jsonl = "tesco_wines_cleaned_for_rag.jsonl"

try:
    # Save as standard JSON (good for general use)
    with open(output_filename_json, "w", encoding='utf-8') as f_json:
        json.dump(cleaned_wine_list, f_json, indent=2, ensure_ascii=False)
    print(f"\nSaved cleaned list as standard JSON to: {output_filename_json}")

    # Save as JSON Lines (ideal for RAG file upload)
    with open(output_filename_jsonl, "w", encoding='utf-8') as f_jsonl:
        for entry in cleaned_wine_list:
            json.dump(entry, f_jsonl, ensure_ascii=False) # Write each dict as a line
            f_jsonl.write('\n') # Add newline character
    print(f"Saved cleaned list as JSON Lines (for RAG) to: {output_filename_jsonl}")

except Exception as e:
    print(f"\nError saving cleaned list to file: {e}")